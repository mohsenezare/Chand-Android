package ir.personal.chand.data

import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class MarketParsersTest {
    private val usd = DEFAULT_MARKET_DESCRIPTORS.first { it.id == "usd" }
    private val euro = DEFAULT_MARKET_DESCRIPTORS.first { it.id == "euro" }

    @Test
    fun restValuesAreConvertedFromRialToTomanAndKeepSourceTimestamp() {
        val body = """
            {
              "response": {
                "indicators": [{
                  "name": "price_dollar_realtime",
                  "p": "2,122,000",
                  "d": "59,000",
                  "dp": "2.86",
                  "dt": "high",
                  "h": "2,130,000",
                  "l": "2,010,000",
                  "updated_at": "2026-08-31 10:02:03"
                }]
              }
            }
        """.trimIndent()

        val parsed = MarketParsers.parseTgjuIndicators(body, listOf(usd), emptyMap(), 123L)
        val item = parsed.items.single()
        assertEquals(212_200.0, item.price, 0.001)
        assertEquals(5_900.0, item.change, 0.001)
        assertEquals(213_000.0, item.high, 0.001)
        assertEquals(201_000.0, item.low, 0.001)
        assertEquals(
            LocalDateTime.of(2026, 8, 31, 10, 2, 3)
                .atZone(ZoneId.of("Asia/Tehran")).toInstant().toEpochMilli(),
            item.sourceUpdatedAtMillis
        )
        assertEquals(DataOrigin.NETWORK, item.origin)
        assertTrue(parsed.missingSourceKeys.isEmpty())
    }

    @Test
    fun missingRestRowsAreReportedAndNeverFabricated() {
        val body = """{"response":{"indicators":[{"name":"price_dollar_realtime","p":"2122000"}]}}"""
        val parsed = MarketParsers.parseTgjuIndicators(
            body,
            listOf(usd, euro),
            emptyMap(),
            123L
        )
        assertEquals(listOf("usd"), parsed.items.map(MarketItem::id))
        assertEquals(setOf("price_eur"), parsed.missingSourceKeys)
        assertEquals(0L, parsed.items.single().sourceUpdatedAtMillis)
    }

    @Test
    fun negativeQuoteUsesProviderTimeAndConvertsRials() {
        val body = """{"response":{"indicators":[{
            "name":"price_eur","p":"2464000","d":"74000","dp":"3.10",
            "dt":"low","updated_at":"2026-08-31 10:02:04"
        }]}}"""
        val item = MarketParsers.parseTgjuIndicators(body, listOf(euro), emptyMap(), 123L).items.single()
        assertEquals(246_400.0, item.price, 0.001)
        assertEquals(-7_400.0, item.change, 0.001)
        assertEquals(-3.10, item.changePercent, 0.001)
        assertTrue(item.sourceUpdatedAtMillis > 0L)
    }

    @Test
    fun historyParsersNormalizeValuesAndDates() {
        val today = MarketParsers.parseTodayHistory(
            """{"data":[["2122000","10:01:00"],["2123000","10:02:00"]]}""",
            LocalDate.of(2026, 8, 31),
            0.1
        )
        assertEquals(listOf(212_200.0, 212_300.0), today.map(PricePoint::value))

        val historical = MarketParsers.parseHistoricalHistory(
            """{"data":[[0,0,0,"2100000",0,0,"2026/08/30"],[0,0,0,"2122000",0,0,"2026/08/31"]]}""",
            0.1
        )
        assertEquals(listOf(210_000.0, 212_200.0), historical.map(PricePoint::value))
        assertTrue(historical[0].timestampMillis < historical[1].timestampMillis)
    }

    @Test
    fun downsampleKeepsFirstAndLastObservations() {
        val input = (0 until 1_000).map { PricePoint(it.toLong() + 1L, (it % 37).toDouble() + 1.0) }
        val output = MarketParsers.downsample(input, 100)
        assertTrue(output.size <= 100)
        assertEquals(input.first(), output.first())
        assertEquals(input.last(), output.last())
    }
}
