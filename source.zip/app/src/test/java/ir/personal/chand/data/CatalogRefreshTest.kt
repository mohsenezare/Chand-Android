package ir.personal.chand.data

import java.io.IOException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.*
import org.junit.Test

class CatalogRefreshTest {
    private fun item(id: String, name: String = id) = MarketDescriptor(
        id, id, name, id, id, MarketSource.TGJU, "test", "")

    @Test fun partialCatalogPreservesOldSymbolsAndUsesFreshMetadata() {
        val old = listOf(item("a", "old"), item("b"))
        val result = CatalogRefresh.merge(old, listOf(item("a", "new"), item("c")))
        assertEquals(listOf("a", "b", "c"), result.map { it.id })
        assertEquals("new", result.first().name)
        assertEquals("old", old.first().name)
    }

    @Test fun mergeIsIdempotentAndDeduplicatesIncomingSymbols() {
        val incoming = listOf(item("a"), item("a"), item("b"))
        val first = CatalogRefresh.merge(emptyList(), incoming)
        assertEquals(2, first.size)
        assertEquals(first, CatalogRefresh.merge(first, incoming))
    }

    @Test fun transientFailureRetriesOnce() = runBlocking {
        var attempts = 0
        val result = CatalogRefresh.retry(0) {
            attempts++
            if (attempts == 1) throw IOException("connection reset")
            "ok"
        }
        assertEquals("ok", result)
        assertEquals(2, attempts)
    }

    @Test fun permanentFailureStopsAfterTwoAttempts() = runBlocking {
        var attempts = 0
        try {
            CatalogRefresh.retry(0) { attempts++; throw IOException("offline") }
            fail("Must report failure")
        } catch (_: IOException) {
            assertEquals(2, attempts)
        }
    }

    @Test fun rateLimitsAndForbiddenResponsesAreNotRetried() = runBlocking {
        for (code in listOf(403, 429)) {
            var attempts = 0
            try {
                CatalogRefresh.retry(0) { attempts++; throw IOException("HTTP $code") }
                fail("Must report provider failure")
            } catch (_: IOException) {
                assertEquals(1, attempts)
            }
        }
    }

    @Test fun timeoutCancelsFetchWithoutRetrying() = runBlocking {
        var attempts = 0
        try {
            withTimeout(30) {
                CatalogRefresh.retry(0) { attempts++; delay(10_000) }
            }
            fail("Expected cancellation")
        } catch (_: CancellationException) {
            assertEquals(1, attempts)
        }
    }
}
