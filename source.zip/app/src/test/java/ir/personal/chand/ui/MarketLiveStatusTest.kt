package ir.personal.chand.ui

import ir.personal.chand.data.*
import org.junit.Assert.assertEquals
import org.junit.Test

class MarketLiveStatusTest {
    private val now = 1_800_000_000_000L
    private fun quote(source: MarketSource) = MarketItem(
        id = "test", name = "Test", code = "TEST", symbol = "TEST",
        price = 100.0, change = 0.0, changePercent = 0.0,
        high = 100.0, low = 100.0, buy = 100.0, sell = 100.0,
        history = emptyList(), sourceUpdatedAtMillis = now,
        receivedAtMillis = now, origin = DataOrigin.NETWORK,
        isAvailable = true, source = source
    )
    @Test fun freshSourceQuotesAreLiveForEveryProvider() {
        MarketSource.entries.forEach { assertEquals("LIVE", MarketLiveStatus.label(quote(it), now)) }
    }
    @Test fun newlyDownloadedOldClosingPriceIsNotLive() {
        MarketSource.entries.forEach {
            assertEquals("—", MarketLiveStatus.label(quote(it).copy(liveQuoteAtMillis = now - 86_400_000), now))
        }
    }
    @Test fun missingTimestampCannotBorrowHttpReceiptTime() {
        MarketSource.entries.forEach {
            assertEquals("—", MarketLiveStatus.label(quote(it).copy(liveQuoteAtMillis = 0), now))
        }
    }
    @Test fun cacheUnavailableAndFutureDatesAreNotLive() {
        val q = quote(MarketSource.TSETMC)
        listOf(q.copy(origin = DataOrigin.CACHE), q.copy(isAvailable = false),
            q.copy(liveQuoteAtMillis = now + 1), q.copy(origin = DataOrigin.UNAVAILABLE))
            .forEach { assertEquals("—", MarketLiveStatus.label(it, now)) }
    }
    @Test fun unchangedPriceWithFreshTradeTimeRemainsLive() {
        val q = quote(MarketSource.TRADINGVIEW)
        assertEquals("LIVE", MarketLiveStatus.label(q.copy(liveQuoteAtMillis = now - 30_000), now))
    }
    @Test fun liveExpiresWithoutReceivingAnotherQuote() {
        val q = quote(MarketSource.TSETMC)
        assertEquals("LIVE", MarketLiveStatus.label(q, now + 90_000))
        assertEquals("—", MarketLiveStatus.label(q, now + 90_001))
    }
}
