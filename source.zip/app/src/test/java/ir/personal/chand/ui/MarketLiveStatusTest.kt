package ir.personal.chand.ui

import ir.personal.chand.data.*
import org.junit.Assert.assertEquals
import org.junit.Test
import java.time.ZonedDateTime

class MarketLiveStatusTest {
    private fun time(value: String) = ZonedDateTime.parse(value).toInstant().toEpochMilli()
    private fun quote(source: MarketSource = MarketSource.TSETMC, id: String = "tsetmc:123", category: String = "بورس ایران", symbol: String = "TSE") = MarketItem(
        id, "Test", "TEST", symbol, 100.0, 0.0, 0.0, 100.0, 100.0, 100.0, 100.0,
        emptyList(), 0L, 0L, DataOrigin.CACHE, false, source, category)
    private fun label(q: MarketItem, date: String) = MarketLiveStatus.label(q, time(date))

    @Test fun iranStockSessionOpensAtNineAndClosesAtTwelveThirty() {
        val q = quote()
        assertEquals("", label(q, "2026-10-25T08:59:00+03:30"))
        assertEquals("LIVE", label(q, "2026-10-25T09:00:00+03:30"))
        assertEquals("LIVE", label(q, "2026-10-25T12:29:59+03:30"))
        assertEquals("", label(q, "2026-10-25T12:30:00+03:30"))
    }
    @Test fun liveDoesNotExpireWithUnchangedOldOrCachedPrice() {
        val q = quote()
        for (hour in 9..12) {
            val now = time("2026-10-25T${hour.toString().padStart(2, '0')}:00:00+03:30")
            for (origin in DataOrigin.entries) {
                assertEquals("LIVE", MarketLiveStatus.label(q.copy(origin = origin, liveQuoteAtMillis = 0L), now))
                assertEquals("LIVE", MarketLiveStatus.label(q.copy(price = 101.0, liveQuoteAtMillis = now), now))
            }
        }
    }
    @Test fun iranThursdayAndFridayAreClosed() {
        assertEquals("", label(quote(), "2026-10-29T10:00:00+03:30"))
        assertEquals("", label(quote(), "2026-10-30T10:00:00+03:30"))
    }
    @Test fun iranOfficialHolidayIsClosed() {
        assertEquals("", label(quote(), "2026-12-23T10:00:00+03:30"))
    }
    @Test fun goldFundHasItsOwnSession() {
        val q = quote(MarketSource.TGJU, "ayar", "صندوق طلا")
        assertEquals("", label(q, "2026-10-25T11:59:00+03:30"))
        assertEquals("LIVE", label(q, "2026-10-25T14:00:00+03:30"))
        assertEquals("", label(q, "2026-10-25T18:00:00+03:30"))
    }
    @Test fun cryptoIsOpenOnWeekendsWithoutAQuote() {
        val q = quote(MarketSource.TRADINGVIEW, "tv:BITSTAMP:BTCUSD", "ارز دیجیتال جهانی", "CRYPTO")
        assertEquals("LIVE", label(q, "2026-10-24T01:00:00Z"))
        assertEquals("LIVE", label(q, "2026-10-25T23:00:00Z"))
    }
    @Test fun forexHasWeekendBoundariesAndNewYorkDaylightSaving() {
        val q = quote(MarketSource.TRADINGVIEW, "tv:FX:EURUSD", "فارکس جهانی", "FX")
        assertEquals("", label(q, "2026-10-25T21:04:00Z"))
        assertEquals("LIVE", label(q, "2026-10-25T21:05:00Z"))
        assertEquals("", label(q, "2026-11-01T21:30:00Z"))
        assertEquals("LIVE", label(q, "2026-11-01T22:05:00Z"))
        assertEquals("", label(q, "2026-10-30T20:59:00Z"))
    }
    @Test fun metalsDailyBreakIsIndependentOfPriceUpdates() {
        val q = quote(MarketSource.TRADINGVIEW, "tv:OANDA:XAUUSD", "طلای جهانی", "GOLD")
        assertEquals("LIVE", label(q, "2026-10-26T20:58:00Z"))
        assertEquals("", label(q, "2026-10-26T21:30:00Z"))
        assertEquals("LIVE", label(q, "2026-10-26T22:05:00Z"))
    }
    @Test fun usEquityHolidayAndEarlyClose() {
        val q = quote(MarketSource.TRADINGVIEW, "tv:NASDAQ:AAPL", "سهام جهانی", "STOCK")
        assertEquals("LIVE", label(q, "2026-10-26T13:30:00Z"))
        assertEquals("", label(q, "2026-11-26T16:00:00Z"))
        assertEquals("LIVE", label(q, "2026-11-27T17:59:00Z"))
        assertEquals("", label(q, "2026-11-27T18:00:00Z"))
    }
    @Test fun domesticCashSessionStaysOpenWithoutTicks() {
        val q = quote(MarketSource.TGJU, "usd", "ارز آزاد", "USD")
        assertEquals("LIVE", label(q, "2026-10-25T15:00:00+03:30"))
        assertEquals("", label(q, "2026-10-25T20:00:00+03:30"))
    }
    @Test fun unknownMarketRendersNothingInsteadOfClosedOrDash() {
        val q = quote(MarketSource.TRADINGVIEW, "tv:UNKNOWN:ABC", "unknown", "STOCK")
        assertEquals("", label(q, "2026-10-26T15:00:00Z"))
    }
}
