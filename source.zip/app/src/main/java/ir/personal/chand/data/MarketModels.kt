package ir.personal.chand.data

enum class MarketSource { TGJU, TSETMC, TRADINGVIEW }

enum class CatalogSource { MARKETS, STOCKS }

enum class DataOrigin { LIVE, NETWORK, CACHE, UNAVAILABLE }

enum class LiveConnectionState { CONNECTING, LIVE, POLLING, OFFLINE }

enum class HistoryRange(val label: String) {
    DAY("1D"),
    WEEK("1W"),
    MONTH("1M"),
    YEAR("1Y"),
    FIVE_YEARS("5Y"),
    ALL("All")
}

data class PricePoint(val timestampMillis: Long, val value: Double)

data class MarketDescriptor(
    val id: String,
    val sourceKey: String,
    val name: String,
    val code: String,
    val symbol: String,
    val source: MarketSource,
    val category: String,
    val unit: String,
    val valueScale: Double = 1.0
)

data class MarketItem(
    val id: String,
    val name: String,
    val code: String,
    val symbol: String,
    val price: Double,
    val change: Double,
    val changePercent: Double,
    val high: Double,
    val low: Double,
    val buy: Double,
    val sell: Double,
    val history: List<PricePoint>,
    val sourceUpdatedAtMillis: Long,
    val receivedAtMillis: Long,
    val origin: DataOrigin,
    val isAvailable: Boolean,
    val source: MarketSource = MarketSource.TGJU,
    val category: String = "",
    val unit: String = "تومان",
    val liveQuoteAtMillis: Long = sourceUpdatedAtMillis
)

data class MarketSnapshot(
    val updatedAt: String,
    val items: List<MarketItem>,
    val isDemo: Boolean,
    val message: String? = null
)

data class CatalogPage(
    val items: List<MarketDescriptor>,
    val hasMore: Boolean,
    val message: String? = null
)

data class HistorySeries(
    val range: HistoryRange,
    val points: List<PricePoint>,
    val message: String? = null
)

data class StreamTick(
    val sourceKey: String,
    val itemId: String,
    val price: Double,
    val high: Double,
    val low: Double,
    val open: Double,
    val change: Double,
    val changePercent: Double,
    val direction: String,
    val sourceUpdatedAtMillis: Long,
    val bid: Double? = null,
    val ask: Double? = null,
    val liveQuoteAtMillis: Long = sourceUpdatedAtMillis
)


enum class ThemeMode { SYSTEM, LIGHT, DARK }

data class UserSettings(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val gridMode: Boolean = true,
    val showBuyPrice: Boolean = false,
    val visibleIds: List<String> = DEFAULT_VISIBLE_IDS
)

val DEFAULT_MARKET_DESCRIPTORS = listOf(
    MarketDescriptor(
        id = "usd",
        sourceKey = "price_dollar_realtime",
        name = "US Dollar",
        code = "USD",
        symbol = "USD",
        source = MarketSource.TGJU,
        category = "ارز آزاد لحظه‌ای",
        unit = "تومان",
        valueScale = 0.1
    ),
    MarketDescriptor(
        id = "euro",
        sourceKey = "price_eur",
        name = "Euro",
        code = "EUR",
        symbol = "EUR",
        source = MarketSource.TGJU,
        category = "ارز آزاد",
        unit = "تومان",
        valueScale = 0.1
    ),
    MarketDescriptor(
        id = "gold18",
        sourceKey = "geram18",
        name = "Gram",
        code = "GRAM",
        symbol = "GRAM",
        source = MarketSource.TGJU,
        category = "طلای ۱۸ عیار",
        unit = "تومان",
        valueScale = 0.1
    ),
    MarketDescriptor(
        id = "emami",
        sourceKey = "sekee",
        name = "Emami",
        code = "EMAMI",
        symbol = "EMAMI",
        source = MarketSource.TGJU,
        category = "سکه امامی",
        unit = "تومان",
        valueScale = 0.1
    ),
    MarketDescriptor(
        id = "usdt",
        sourceKey = "crypto-tether-irr",
        name = "Tether USDT",
        code = "USDT",
        symbol = "USDT",
        source = MarketSource.TGJU,
        category = "ارز دیجیتال داخلی",
        unit = "تومان",
        valueScale = 0.1
    ),
    MarketDescriptor(
        id = "ayar",
        sourceKey = "gc3",
        name = "عیار",
        code = "AYAR",
        symbol = "Au",
        source = MarketSource.TGJU,
        category = "صندوق طلا",
        unit = "ریال",
        valueScale = 1.0
    )
)


val TRADINGVIEW_MARKET_DESCRIPTORS = listOf(
    MarketDescriptor(
        id = "tv:BITSTAMP:BTCUSD",
        sourceKey = "BITSTAMP:BTCUSD",
        name = "Bitcoin",
        code = "BTC/USD",
        symbol = "CRYPTO",
        source = MarketSource.TRADINGVIEW,
        category = "ارز دیجیتال جهانی",
        unit = "دلار"
    ),
    MarketDescriptor(
        id = "tv:BITSTAMP:ETHUSD",
        sourceKey = "BITSTAMP:ETHUSD",
        name = "Ethereum",
        code = "ETH/USD",
        symbol = "CRYPTO",
        source = MarketSource.TRADINGVIEW,
        category = "ارز دیجیتال جهانی",
        unit = "دلار"
    ),
    MarketDescriptor(
        id = "tv:FX:EURUSD",
        sourceKey = "FX:EURUSD",
        name = "EUR/USD",
        code = "EUR/USD",
        symbol = "FX",
        source = MarketSource.TRADINGVIEW,
        category = "فارکس جهانی",
        unit = "دلار"
    ),
    MarketDescriptor(
        id = "tv:FX:GBPUSD",
        sourceKey = "FX:GBPUSD",
        name = "GBP/USD",
        code = "GBP/USD",
        symbol = "FX",
        source = MarketSource.TRADINGVIEW,
        category = "فارکس جهانی",
        unit = "دلار"
    ),
    MarketDescriptor(
        id = "tv:FX:USDJPY",
        sourceKey = "FX:USDJPY",
        name = "USD/JPY",
        code = "USD/JPY",
        symbol = "FX",
        source = MarketSource.TRADINGVIEW,
        category = "فارکس جهانی",
        unit = "ین"
    ),
    MarketDescriptor(
        id = "tv:OANDA:XAUUSD",
        sourceKey = "OANDA:XAUUSD",
        name = "Gold Spot",
        code = "XAU/USD",
        symbol = "GOLD",
        source = MarketSource.TRADINGVIEW,
        category = "طلای جهانی",
        unit = "دلار"
    ),
    MarketDescriptor(
        id = "tv:OANDA:XAGUSD",
        sourceKey = "OANDA:XAGUSD",
        name = "Silver Spot",
        code = "XAG/USD",
        symbol = "SILVER",
        source = MarketSource.TRADINGVIEW,
        category = "نقره جهانی",
        unit = "دلار"
    ),
    MarketDescriptor(
        id = "tv:TVC:UKOIL",
        sourceKey = "TVC:UKOIL",
        name = "Brent Oil",
        code = "BRENT",
        symbol = "OIL",
        source = MarketSource.TRADINGVIEW,
        category = "انرژی جهانی",
        unit = "دلار"
    ),
    MarketDescriptor(
        id = "tv:TVC:USOIL",
        sourceKey = "TVC:USOIL",
        name = "WTI Oil",
        code = "WTI",
        symbol = "OIL",
        source = MarketSource.TRADINGVIEW,
        category = "انرژی جهانی",
        unit = "دلار"
    )
)

val DEFAULT_VISIBLE_IDS = listOf("usd", "euro", "gold18", "emami")

val LEGACY_DEFAULT_VISIBLE_IDS = listOf(
    "usd", "usdt", "gold_world", "gold18", "silver", "brent", "bourse"
)
