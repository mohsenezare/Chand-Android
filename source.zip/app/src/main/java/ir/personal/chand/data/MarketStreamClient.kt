package ir.personal.chand.data

import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONObject
import java.io.Closeable
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.min
import kotlin.random.Random

class MarketStreamClient(
    private val httpClient: OkHttpClient,
    private val onState: (LiveConnectionState) -> Unit,
    private val onTicks: (List<StreamTick>) -> Unit
) : Closeable {
    private val scheduler = Executors.newSingleThreadScheduledExecutor { task ->
        Thread(task, "chand-live-stream").apply { isDaemon = true }
    }
    private val requestId = AtomicInteger(3)
    private val lock = Any()

    @Volatile private var closed = false
    private var socket: WebSocket? = null
    private var retryAttempt = 0
    private var reconnectFuture: ScheduledFuture<*>? = null
    private var heartbeatFuture: ScheduledFuture<*>? = null
    private var quoteWatchdogFuture: ScheduledFuture<*>? = null
    @Volatile private var liveQuoteSeen = false

    fun start() {
        synchronized(lock) {
            if (closed || socket != null) return
            connectLocked()
        }
    }

    private fun connectLocked() {
        reconnectFuture?.cancel(false)
        reconnectFuture = null
        quoteWatchdogFuture?.cancel(false)
        quoteWatchdogFuture = null
        liveQuoteSeen = false
        onState(LiveConnectionState.CONNECTING)
        val request = Request.Builder()
            .url(STREAM_URL)
            .header("Origin", "https://www.tgju.org")
            .header("User-Agent", USER_AGENT)
            .build()
        socket = httpClient.newWebSocket(request, Listener())
    }

    override fun close() {
        synchronized(lock) {
            if (closed) return
            closed = true
            reconnectFuture?.cancel(false)
            heartbeatFuture?.cancel(false)
            quoteWatchdogFuture?.cancel(false)
            reconnectFuture = null
            heartbeatFuture = null
            quoteWatchdogFuture = null
            socket?.close(1000, "app stopped")
            socket = null
        }
        scheduler.shutdownNow()
    }

    private fun sendConnect(webSocket: WebSocket) {
        webSocket.send(
            JSONObject()
                .put("id", 1)
                .put("method", 0)
                .put("params", JSONObject().put("name", "android").put("version", "2.0"))
                .toString()
        )
    }

    private fun sendSubscribe(webSocket: WebSocket) {
        webSocket.send(
            JSONObject()
                .put("id", 2)
                .put("method", 1)
                .put("params", JSONObject().put("channel", STREAM_CHANNEL))
                .toString()
        )
    }

    private fun beginHeartbeat(webSocket: WebSocket) {
        synchronized(lock) {
            heartbeatFuture?.cancel(false)
            heartbeatFuture = scheduler.scheduleWithFixedDelay(
                {
                    if (!closed && socket === webSocket) {
                        webSocket.send(
                            JSONObject()
                                .put("id", requestId.getAndIncrement())
                                .put("method", 7)
                                .toString()
                        )
                    }
                },
                20,
                20,
                TimeUnit.SECONDS
            )
        }
    }

    private fun disconnected(failedSocket: WebSocket) {
        synchronized(lock) {
            if (socket !== failedSocket) return
            socket = null
            heartbeatFuture?.cancel(false)
            quoteWatchdogFuture?.cancel(false)
            heartbeatFuture = null
            quoteWatchdogFuture = null
            liveQuoteSeen = false
            if (closed) return
            onState(LiveConnectionState.POLLING)
            val baseSeconds = min(20, 1 shl retryAttempt.coerceAtMost(4))
            retryAttempt = (retryAttempt + 1).coerceAtMost(8)
            val delayMillis = baseSeconds * 1_000L + Random.nextLong(0L, 500L)
            reconnectFuture?.cancel(false)
            reconnectFuture = scheduler.schedule(
                { synchronized(lock) { if (!closed && socket == null) connectLocked() } },
                delayMillis,
                TimeUnit.MILLISECONDS
            )
        }
    }

    private inner class Listener : WebSocketListener() {
        override fun onOpen(webSocket: WebSocket, response: Response) {
            sendConnect(webSocket)
        }

        override fun onMessage(webSocket: WebSocket, text: String) {
            val messages = runCatching { listOf(JSONObject(text.trim())) }.getOrElse {
                text.lineSequence()
                    .filter(String::isNotBlank)
                    .mapNotNull { line -> runCatching { JSONObject(line) }.getOrNull() }
                    .toList()
            }
            messages.forEach { message ->
                if (message.has("error")) {
                    webSocket.cancel()
                    disconnected(webSocket)
                    return@forEach
                }
                when (message.optInt("id", -1)) {
                    1 -> sendSubscribe(webSocket)
                    2 -> {
                        synchronized(lock) { retryAttempt = 0 }
                        beginHeartbeat(webSocket)
                        quoteWatchdogFuture?.cancel(false)
                        quoteWatchdogFuture = scheduler.schedule(
                            { if (!closed && socket === webSocket && !liveQuoteSeen) onState(LiveConnectionState.POLLING) },
                            FIRST_QUOTE_TIMEOUT_SECONDS,
                            TimeUnit.SECONDS
                        )
                    }
                    else -> {
                        val ticks = MarketParsers.parseStreamMessage(message.toString())
                        if (ticks.isNotEmpty()) {
                            if (!liveQuoteSeen) {
                                liveQuoteSeen = true
                                quoteWatchdogFuture?.cancel(false)
                                quoteWatchdogFuture = null
                                onState(LiveConnectionState.LIVE)
                            }
                            onTicks(ticks)
                        }
                    }
                }
            }
        }

        override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
            webSocket.close(code, reason)
        }

        override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
            disconnected(webSocket)
        }

        override fun onFailure(webSocket: WebSocket, throwable: Throwable, response: Response?) {
            disconnected(webSocket)
        }
    }

    companion object {
        const val STREAM_URL = "wss://stream.tgju.org/connection/websocket"
        const val STREAM_CHANNEL = "tgju:stream"
        const val USER_AGENT = "ChandPersonalAndroid/4.0"
        private const val FIRST_QUOTE_TIMEOUT_SECONDS = 10L
    }
}
