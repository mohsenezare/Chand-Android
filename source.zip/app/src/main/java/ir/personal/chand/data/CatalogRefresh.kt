package ir.personal.chand.data

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay

internal data class CatalogRefreshResult(
    val items: List<MarketDescriptor>,
    val complete: Boolean = true
)

internal object CatalogRefresh {
    // Catalog searches/watchlists may be partial. Preserve prior selectable symbols.
    fun merge(old: List<MarketDescriptor>, fresh: List<MarketDescriptor>): List<MarketDescriptor> {
        val result = linkedMapOf<String, MarketDescriptor>()
        old.forEach { result[it.id] = it }
        fresh.forEach { result[it.id] = it }
        return result.values.toList()
    }

    suspend fun <T> retry(pauseMillis: Long = 450L, block: suspend () -> T): T {
        try {
            return block()
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (failure: Exception) {
            // An authorization/rate-limit response needs user/server intervention.
            if (listOf("HTTP 400", "HTTP 401", "HTTP 403", "HTTP 404", "HTTP 429")
                    .any { failure.message.orEmpty().contains(it) }) throw failure
            delay(pauseMillis)
            return block()
        }
    }
}
