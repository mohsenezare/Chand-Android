package ir.personal.chand.ui

import ir.personal.chand.data.DataOrigin
import ir.personal.chand.data.MarketItem
import ir.personal.chand.data.MarketSource

/** LIVE means a recent timestamp supplied by the quote source, not an HTTP receipt.
 * A stale/unknown quote cannot prove that its exchange is closed (halt, delay,
 * holiday or connectivity loss are all possible), so it is shown as an em dash.
 */
object MarketLiveStatus {
    fun label(item: MarketItem, now: Long = System.currentTimeMillis()): String {
        if (!item.isAvailable || item.origin == DataOrigin.CACHE ||
            item.origin == DataOrigin.UNAVAILABLE) return "—"
        val time = item.liveQuoteAtMillis
        if (time <= 0L || time > now) return "—"
        val maxAge = when (item.source) {
            MarketSource.TRADINGVIEW, MarketSource.TSETMC -> 90_000L
            MarketSource.TGJU -> 90_000L
        }
        return if (now - time <= maxAge) "LIVE" else "—"
    }
}
