package ir.personal.chand.ui

import ir.personal.chand.data.MarketItem
import ir.personal.chand.data.MarketSource
import java.time.DayOfWeek
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime
import java.util.Locale

/** A market-session indicator, deliberately independent of quote age, cache,
 * availability, connectivity, and price changes. Unknown sessions render nothing.
 * Ordinary sessions and published holidays; emergency exchange closures and
 * individual instrument suspensions require an authoritative status feed.
 */
object MarketLiveStatus {
    fun label(item: MarketItem, now: Long = System.currentTimeMillis()): String =
        if (isOpen(item, Instant.ofEpochMilli(now))) "LIVE" else ""

    private fun isOpen(item: MarketItem, instant: Instant): Boolean {
        val text = "${item.id} ${item.code} ${item.symbol} ${item.category} ${item.name}".uppercase(Locale.ROOT)
        if (item.symbol == "CRYPTO" || item.category.contains("ارز دیجیتال") ||
            item.id == "usdt" || item.id.startsWith("tgju:crypto-")) return true
        val domestic = item.source != MarketSource.TRADINGVIEW
        if (domestic) {
            val local = instant.atZone(ZoneId.of("Asia/Tehran"))
            if (iranHoliday(local.toLocalDate()) || local.dayOfWeek == DayOfWeek.FRIDAY) return false
            val goldFund = item.id == "ayar" || item.code.equals("AYAR", true) || item.code == "عیار" ||
                ((text.contains("صندوق") || text.contains("پشتوانه")) && text.contains("طلا"))
            if (goldFund) return local.dayOfWeek != DayOfWeek.THURSDAY && between(local, 720, 1080)
            if (item.source == MarketSource.TSETMC || item.category.contains("بورس") || item.category.contains("سهام")) {
                if (local.dayOfWeek == DayOfWeek.THURSDAY) return false
                return between(local, 540, 750)
            }
            // Indicative domestic cash-market session; this OTC market has no
            // single exchange bell. Never infer it from an incoming price tick.
            if (item.id in setOf("usd", "euro", "gold18", "emami") ||
                item.category.contains("ارز آزاد") || item.category.contains("سکه") ||
                item.category.contains("طلای") || item.category.contains("بازار داخلی")) {
                return between(local, 600, 1200)
            }
            return false
        }
        val newYork = instant.atZone(ZoneId.of("America/New_York"))
        val exchange = item.id.removePrefix("tv:").substringBefore(':').uppercase(Locale.ROOT)
        if (exchange in setOf("NYSE", "NASDAQ", "AMEX", "NYSEARCA", "NYSEAMERICAN", "ARCA")) {
            val date = newYork.toLocalDate()
            if (newYork.dayOfWeek.value >= 6 || date.toString() in usHolidays) return false
            return between(newYork, 570, if (date.toString() in usEarlyCloses) 780 else 960)
        }
        if (item.symbol == "FX" || item.category.contains("فارکس")) {
            if (newYork.monthValue == 12 && newYork.dayOfMonth == 25 ||
                newYork.monthValue == 1 && newYork.dayOfMonth == 1) return false
            return overnightWeek(newYork, 1025, 1019)
        }
        if (item.symbol in setOf("GOLD", "SILVER") || text.contains("XAU/") || text.contains("XAG/") ||
            text.contains("XAUUSD") || text.contains("XAGUSD")) {
            if (newYork.monthValue == 12 && newYork.dayOfMonth == 25 ||
                newYork.monthValue == 1 && newYork.dayOfMonth == 1) return false
            return overnightWeek(newYork, 1085, 1019)
        }
        if (item.code == "WTI" || text.contains("USOIL")) return overnightWeek(newYork, 1081, 1019)
        if (item.code == "BRENT" || text.contains("UKOIL")) {
            val london = instant.atZone(ZoneId.of("Europe/London"))
            val minute = london.hour * 60 + london.minute
            return when (london.dayOfWeek) {
                DayOfWeek.SATURDAY -> false
                DayOfWeek.SUNDAY -> minute >= 1381
                DayOfWeek.MONDAY -> minute < 1319 || minute in 1325 until 1379
                DayOfWeek.FRIDAY -> minute in 61 until 1319
                else -> minute in 61 until 1319 || minute in 1325 until 1379
            }
        }
        // Unknown exchange/type: do not pretend that a fresh quote proves it open.
        return false
    }

    private fun between(local: ZonedDateTime, start: Int, end: Int): Boolean =
        local.hour * 60 + local.minute in start until end

    private fun overnightWeek(local: ZonedDateTime, open: Int, close: Int): Boolean {
        val minute = local.hour * 60 + local.minute
        return when (local.dayOfWeek) {
            DayOfWeek.SATURDAY -> false
            DayOfWeek.SUNDAY -> minute >= open
            DayOfWeek.FRIDAY -> minute < close
            else -> minute < close || minute >= open
        }
    }

    private fun iranHoliday(date: LocalDate): Boolean {
        val p = PersianDateTime.fromGregorian(date.year, date.monthValue, date.dayOfMonth)
        val md = p.month * 100 + p.day
        return md in setOf(101, 102, 103, 104, 112, 113, 314, 315, 1122, 1229) ||
            (p.year == 1405 && md in iran1405)
    }

    private val iran1405 = setOf(101, 102, 103, 104, 112, 113, 125, 306, 314, 315,
        403, 404, 513, 521, 522, 530, 608, 822, 1002, 1016, 1104, 1122, 1209, 1219, 1220, 1229)
    private val usHolidays = setOf(
        "2026-01-01", "2026-01-19", "2026-02-16", "2026-04-03", "2026-05-25",
        "2026-06-19", "2026-07-03", "2026-09-07", "2026-11-26", "2026-12-25",
        "2027-01-01", "2027-01-18", "2027-02-15", "2027-03-26", "2027-05-31",
        "2027-06-18", "2027-07-05", "2027-09-06", "2027-11-25", "2027-12-24")
    private val usEarlyCloses = setOf("2026-11-27", "2026-12-24", "2027-11-26")
}
