package ir.personal.chand.data

import java.time.DayOfWeek
import java.time.Instant
import java.time.LocalTime
import java.time.ZoneId

/** Conservative exchange-hours guard. A recent quote is not proof that a market is open.
 * Holidays and instrument-specific halts still require provider trading-status data.
 */
object MarketSession {
    private val tehran = ZoneId.of("Asia/Tehran")
    private val newYork = ZoneId.of("America/New_York")

    fun isScheduledOpen(item: MarketItem, nowMillis: Long): Boolean {
        val key = (item.id + " " + item.code + " " + item.symbol + " " + item.category + " " + item.name).lowercase()
        val crypto = "crypto" in key || "رمز" in key || "bitcoin" in key ||
            "ethereum" in key || "tether" in key || "btc" in key || "usdt" in key
        if (crypto && item.source != MarketSource.TSETMC) return true

        if (item.source == MarketSource.TSETMC) {
            val local = Instant.ofEpochMilli(nowMillis).atZone(tehran)
            return local.dayOfWeek in setOf(DayOfWeek.SATURDAY, DayOfWeek.SUNDAY,
                DayOfWeek.MONDAY, DayOfWeek.TUESDAY, DayOfWeek.WEDNESDAY) &&
                inTime(local.toLocalTime(), 9, 0, 12, 30)
        }
        if (item.source == MarketSource.TGJU) {
            val local = Instant.ofEpochMilli(nowMillis).atZone(tehran)
            return local.dayOfWeek != DayOfWeek.FRIDAY &&
                inTime(local.toLocalTime(), 9, 0, if (local.dayOfWeek == DayOfWeek.THURSDAY) 16 else 20, 0)
        }
        val local = Instant.ofEpochMilli(nowMillis).atZone(newYork)
        val minute = local.hour * 60 + local.minute
        // FX and energy feeds: closed over the weekend and during the daily rollover.
        val isFxOrEnergy = "fx" in key || "فارکس" in key || "oil" in key ||
            "نفت" in key || "xau" in key || "xag" in key || "gold" in key ||
            "silver" in key || "طلا" in key || "نقره" in key || "brent" in key || "wti" in key
        if (isFxOrEnergy) return when (local.dayOfWeek) {
            DayOfWeek.SATURDAY -> false
            DayOfWeek.SUNDAY -> minute >= 18 * 60
            DayOfWeek.FRIDAY -> minute < 17 * 60
            else -> minute < 17 * 60 || minute >= 18 * 60
        }
        // Conventional exchanges: never label a quote LIVE during their known off-hours.
        return local.dayOfWeek in setOf(DayOfWeek.MONDAY, DayOfWeek.TUESDAY,
            DayOfWeek.WEDNESDAY, DayOfWeek.THURSDAY, DayOfWeek.FRIDAY) &&
            inTime(local.toLocalTime(), 9, 30, 16, 0)
    }

    private fun inTime(time: LocalTime, openH: Int, openM: Int, closeH: Int, closeM: Int): Boolean =
        !time.isBefore(LocalTime.of(openH, openM)) && time.isBefore(LocalTime.of(closeH, closeM))

    fun shouldDisplayLive(item: MarketItem, nowMillis: Long): Boolean {
        if (!item.isAvailable || item.sourceUpdatedAtMillis <= 0L) return false
        if (!isScheduledOpen(item, nowMillis)) return false
        val age = nowMillis - item.sourceUpdatedAtMillis
        if (age < -60_000L) return false
        val maxAge = when (item.source) {
            MarketSource.TRADINGVIEW -> 5L * 60_000
            MarketSource.TSETMC -> 5L * 60_000
            MarketSource.TGJU -> 10L * 60_000
        }
        return age <= maxAge
    }
}
