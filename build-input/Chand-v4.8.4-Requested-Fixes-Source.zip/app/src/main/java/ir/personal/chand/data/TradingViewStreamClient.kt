package ir.personal.chand.data

import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.Closeable
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.util.Locale
import java.util.UUID
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit

/**
 * Investing.com quote client for global markets.
 *
 * Uses Investing.com's tvc6 service. Symbols are resolved once through the
 * Investing search endpoint and all visible globals are then polled together.
 */
class TradingViewStreamClient(
    private val httpClient: OkHttpClient,
    symbols: List<String>,
    private val onState: (LiveConnectionState) -> Unit,
    private val onTicks: (List<StreamTick>) -> Unit
) : Closeable {
    private val requestedSymbols = symbols.map(String::trim).filter(String::isNotBlank).distinct()
    private val scheduler = Executors.newSingleThreadScheduledExecutor { task ->
        Thread(task, "chand-investing-live").apply { isDaemon = true }
    }
    private val resolved = linkedMapOf<String, String>()

    @Volatile private var closed = false
    private var future: ScheduledFuture<*>? = null
    private var consecutiveFailures = 0

    fun start() {
        if (requestedSymbols.isEmpty() || closed) return
        onState(LiveConnectionState.CONNECTING)
        future = scheduler.scheduleWithFixedDelay(
            { pollSafely() },
            0L,
            POLL_INTERVAL_MS,
            TimeUnit.MILLISECONDS
        )
    }

    private fun pollSafely() {
        if (closed) return
        try {
            resolveMissingSymbols()
            if (resolved.isEmpty()) {
                onState(LiveConnectionState.POLLING)
                return
            }

            val url = endpoint("quotes") +
                "?symbols=" + encode(resolved.values.distinct().joinToString(","))
            val root = JSONObject(get(url))
            val rows = root.optJSONArray("d") ?: JSONArray()
            val sourceByInvesting = resolved.entries.associate { it.value to it.key }
            val receivedAt = System.currentTimeMillis()

            val ticks = buildList {
                for (index in 0 until rows.length()) {
                    val row = rows.optJSONObject(index) ?: continue
                    val status = row.optString("s")
                    if (status.isNotBlank() && !status.equals("ok", ignoreCase = true)) continue

                    val investingName = row.optString("n").trim()
                    val sourceKey = sourceByInvesting[investingName]
                        ?: resolved.entries.firstOrNull {
                            it.value.equals(investingName, ignoreCase = true)
                        }?.key
                        ?: continue
                    val value = row.optJSONObject("v") ?: continue
                    val price = number(value.opt("lp"))
                        ?: number(value.opt("last"))
                        ?: number(value.opt("close"))
                        ?: continue
                    if (!price.isFinite() || price <= 0.0) continue

                    val change = number(value.opt("ch")) ?: number(value.opt("rch")) ?: 0.0
                    val percent = number(value.opt("chp")) ?: number(value.opt("rchp")) ?: 0.0
                    val high = number(value.opt("high_price")) ?: number(value.opt("high")) ?: price
                    val low = number(value.opt("low_price")) ?: number(value.opt("low")) ?: price
                    val open = number(value.opt("open_price")) ?: number(value.opt("open")) ?: price
                    val timestamp = sourceTimestamp(value) ?: receivedAt

                    add(
                        StreamTick(
                            sourceKey = sourceKey,
                            itemId = "tv:$sourceKey",
                            price = price,
                            high = high.takeIf { it > 0.0 } ?: price,
                            low = low.takeIf { it > 0.0 } ?: price,
                            open = open.takeIf { it > 0.0 } ?: price,
                            change = change,
                            changePercent = percent,
                            direction = when {
                                change > 0.0 -> "high"
                                change < 0.0 -> "low"
                                else -> "same"
                            },
                            sourceUpdatedAtMillis = timestamp,
                            bid = number(value.opt("bid")),
                            ask = number(value.opt("ask"))
                        )
                    )
                }
            }

            if (ticks.isNotEmpty()) {
                consecutiveFailures = 0
                onTicks(ticks)
                onState(LiveConnectionState.LIVE)
            } else {
                consecutiveFailures++
                onState(LiveConnectionState.POLLING)
                if (consecutiveFailures % 5 == 0) resolved.clear()
            }
        } catch (_: Throwable) {
            consecutiveFailures++
            onState(LiveConnectionState.POLLING)
            if (consecutiveFailures % 5 == 0) resolved.clear()
        }
    }

    private fun resolveMissingSymbols() {
        requestedSymbols.forEach { sourceKey ->
            if (resolved.containsKey(sourceKey)) return@forEach

            directInvestingName(sourceKey)?.let { direct ->
                resolved[sourceKey] = direct
                return@forEach
            }

            val target = queryFor(sourceKey)
            val preferredExchange = sourceKey.substringBefore(':', "").uppercase(Locale.US)
            val expectedToken = normalize(sourceKey.substringAfterLast(':'))
            val url = endpoint("search") +
                "?query=" + encode(target) + "&limit=12&type=&exchange="
            val rows = runCatching { JSONArray(get(url)) }.getOrNull()

            val best = if (rows != null) {
                (0 until rows.length())
                    .mapNotNull(rows::optJSONObject)
                    .maxByOrNull { score(it, target, preferredExchange, expectedToken) }
            } else null

            val fullName = best?.optString("full_name")?.trim().orEmpty()
            val exchange = best?.optString("exchange")?.trim().orEmpty()
            val symbol = best?.optString("symbol")?.trim().orEmpty()

            resolved[sourceKey] = when {
                fullName.isNotBlank() -> fullName
                exchange.isNotBlank() && symbol.isNotBlank() -> "$exchange:$symbol"
                else -> sourceKey
            }
        }
    }

    private fun score(
        row: JSONObject,
        target: String,
        preferredExchange: String,
        expectedToken: String
    ): Int {
        val symbol = row.optString("symbol").trim()
        val fullName = row.optString("full_name").trim()
        val description = row.optString("description").trim()
        val exchange = row.optString("exchange").trim().uppercase(Locale.US)
        val type = row.optString("type").trim().lowercase(Locale.US)

        val symbolToken = normalize(symbol)
        val fullToken = normalize(fullName.substringAfterLast(':'))
        val targetToken = normalize(target)
        var score = 0
        if (symbolToken == expectedToken) score += 160
        if (fullToken == expectedToken) score += 150
        if (symbolToken == targetToken) score += 130
        if (fullToken == targetToken) score += 120
        if (description.contains(target, ignoreCase = true)) score += 70
        if (preferredExchange.isNotBlank() && exchange == preferredExchange) score += 35
        if (expectedToken in setOf("XAUUSD", "XAGUSD", "EURUSD", "GBPUSD", "USDJPY") &&
            (type.contains("fx") || type.contains("currency"))) score += 40
        if (expectedToken in setOf("BTCUSD", "ETHUSD") && type.contains("crypto")) score += 40
        if (expectedToken == "UKOIL" && description.contains("brent", true)) score += 80
        if (expectedToken == "USOIL" &&
            (description.contains("wti", true) || description.contains("crude oil", true))) score += 80
        return score
    }

    private fun directInvestingName(sourceKey: String): String? {
        val token = normalize(sourceKey.substringAfterLast(':'))
        val direct = when (token) {
            "BTCUSD" -> ":BTC/USD"
            "ETHUSD" -> ":ETH/USD"
            "EURUSD" -> ":EUR/USD"
            "GBPUSD" -> ":GBP/USD"
            "USDJPY" -> ":USD/JPY"
            "XAUUSD" -> ":XAU/USD"
            "XAGUSD" -> ":XAG/USD"
            else -> null
        }
        if (direct != null) return direct

        val prefix = sourceKey.substringBefore(':', "").uppercase(Locale.US)
        return if (sourceKey.startsWith(":") ||
            (sourceKey.contains(':') && prefix !in setOf("BITSTAMP", "FX", "FX_IDC", "OANDA", "FOREXCOM", "TVC"))
        ) sourceKey else null
    }

    private fun queryFor(sourceKey: String): String =
        when (normalize(sourceKey.substringAfterLast(':'))) {
            "BTCUSD" -> "BTC/USD"
            "ETHUSD" -> "ETH/USD"
            "EURUSD" -> "EUR/USD"
            "GBPUSD" -> "GBP/USD"
            "USDJPY" -> "USD/JPY"
            "XAUUSD" -> "XAU/USD"
            "XAGUSD" -> "XAG/USD"
            "UKOIL" -> "Brent Oil"
            "USOIL" -> "Crude Oil WTI"
            else -> sourceKey.substringAfterLast(':')
        }

    private fun get(url: String): String {
        val request = Request.Builder()
            .url(url)
            .header("Accept", "application/json,text/plain,*/*")
            .header("Cache-Control", "no-cache")
            .header("Pragma", "no-cache")
            .header("Referer", "https://tvc-invdn-com.investing.com/")
            .header("User-Agent", USER_AGENT)
            .build()

        return httpClient.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error("Investing HTTP ${response.code}")
            response.body?.string()?.takeIf(String::isNotBlank)
                ?: error("Empty Investing response")
        }
    }

    private fun endpoint(name: String): String =
        "$BASE/${UUID.randomUUID().toString().replace("-", "")}/0/0/0/0/$name"

    override fun close() {
        closed = true
        future?.cancel(true)
        future = null
        scheduler.shutdownNow()
    }

    companion object {
        private const val BASE = "https://tvc6.investing.com"
        private const val POLL_INTERVAL_MS = 1_000L
        private const val USER_AGENT =
            "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126 Mobile Safari/537.36"

        private fun encode(value: String): String =
            URLEncoder.encode(value, StandardCharsets.UTF_8.toString())

        private fun normalize(value: String): String =
            value.uppercase(Locale.US).filter(Char::isLetterOrDigit)

        private fun sourceTimestamp(value: JSONObject): Long? {
            val raw = sequenceOf(
                value.opt("lp_time"),
                value.opt("trade_time"),
                value.opt("rtc"),
                value.opt("timestamp")
            ).mapNotNull(::number).firstOrNull { it > 0.0 } ?: return null
            val millis = if (raw < 10_000_000_000L) (raw * 1000.0).toLong() else raw.toLong()
            return millis.takeIf { it in 946684800000L..4102444800000L }
        }

        private fun number(raw: Any?): Double? = when (raw) {
            null, JSONObject.NULL -> null
            is Number -> raw.toDouble()
            else -> raw.toString().replace(",", "").trim().toDoubleOrNull()
        }
    }
}
