package ir.personal.chand.ui

/** One trigger per touch gesture, independent of fling delivery and recomposition. */
internal class PullRefreshGesture(private val threshold: Float) {
    private var distance = 0f
    private var fired = false

    fun reset() { distance = 0f; fired = false }

    fun drag(delta: Float, atTop: Boolean, refreshing: Boolean): Boolean {
        if (refreshing) { distance = 0f; return false }
        if (!atTop || delta < 0f) { distance = 0f; return false }
        if (fired || delta <= 0f) return false
        distance += delta
        if (distance < threshold) return false
        fired = true
        return true
    }
}
