package ir.personal.chand.data

import java.time.DayOfWeek
import java.time.Instant
import java.time.LocalTime
import java.time.ZoneId
import java.util.Locale

/** Conservative status indicator: a received HTTP response is not a trade. */
object MarketSessionStatus {
    private val tehran = ZoneId.of("Asia/Tehran")
    private val newYork = ZoneId.of("America/New_York")

    enum class Status { LIVE, CLOSED, STALE }

    fun status(item: MarketItem, now: Long): Status = when {
        !isSessionOpen(item, now) -> Status.CLOSED
        isLive(item, now) -> Status.LIVE
        else -> Status.STALE
    }

    fun isLive(item: MarketItem, now: Long = System.currentTimeMillis()): Boolean {
        if (!item.isAvailable || !item.price.isFinite() || item.price <= 0.0) return false
        if (item.origin == DataOrigin.CACHE || item.origin == DataOrigin.UNAVAILABLE) return false
        val timestamp = item.sourceUpdatedAtMillis
        if (timestamp <= 0L || timestamp > now + 120_000L) return false
        if (!isSessionOpen(item, now)) return false
        val maxAge = when (item.source) {
            MarketSource.TRADINGVIEW -> 5L * 60_000L
            MarketSource.TSETMC -> 30L * 60_000L
            MarketSource.TGJU -> 20L * 60_000L
        }
        return now - timestamp <= maxAge
    }

    /** Session hours are indicative; an exchange holiday or halt requires provider data. */
    fun isSessionOpen(item: MarketItem, now: Long): Boolean = when (item.source) {
        MarketSource.TRADINGVIEW -> isGlobalSessionOpen(item.id + " " + item.code, item.category, now)
        MarketSource.TSETMC -> isIranStockSessionOpen(item, now)
        MarketSource.TGJU -> isIranMarketSessionOpen(item, now)
    }

    fun isGlobalSessionOpen(symbol: String, category: String, now: Long): Boolean {
        val key = symbol.uppercase(Locale.US).replace(Regex("[^A-Z0-9]"), "")
        val isCrypto = category.contains("ارز دیجیتال") ||
            category.contains("crypto", true) ||
            listOf("BTC", "ETH", "USDT", "SOL", "DOGE", "LTC", "XRP", "ADA", "BNB").any { key.contains(it) }
        if (isCrypto) return true

        val ny = Instant.ofEpochMilli(now).atZone(newYork)
        val day = ny.dayOfWeek
        val time = ny.toLocalTime()
        // Most FX and spot-metal/energy CFDs use the New York weekly rollover.
        val forex = category.contains("فارکس") || category.contains("forex", true) ||
            key.contains("XAU") || key.contains("XAG") ||
            key.contains("EURUSD") || key.contains("GBPUSD") || key.contains("USDJPY") ||
            key.contains("USDCHF") || key.contains("AUDUSD") || key.contains("USDCAD") ||
            key.contains("NZDUSD")
        val metalOrEnergy = key.contains("XAU") || key.contains("XAG") ||
            key.contains("OIL") || key.contains("BRENT") || key.contains("WTI") ||
            category.contains("انرژی") || category.contains("نفت") ||
            category.contains("فلز") || category.contains("طلای جهانی") || category.contains("نقره جهانی")
        if (forex || metalOrEnergy) {
            val startSunday = if (metalOrEnergy) LocalTime.of(18, 0) else LocalTime.of(17, 0)
            return when (day) {
                DayOfWeek.SATURDAY -> false
                DayOfWeek.SUNDAY -> !time.isBefore(startSunday)
                DayOfWeek.FRIDAY -> time.isBefore(LocalTime.of(17, 0))
                else -> !metalOrEnergy || time.isBefore(LocalTime.of(17, 0)) || !time.isBefore(LocalTime.of(18, 0))
            }
        }
        // Listed US stocks/ETFs have a different daily session from FX.
        val isUsEquity = listOf("NASDAQ", "NYSE", "AMEX", "NYSEARCA").any { key.contains(it) }
        if (isUsEquity) {
            return day in DayOfWeek.MONDAY..DayOfWeek.FRIDAY &&
                !time.isBefore(LocalTime.of(9, 30)) && time.isBefore(LocalTime.of(16, 0))
        }
        // An unknown exchange does not inherit arbitrary US market hours.
        return day != DayOfWeek.SATURDAY && day != DayOfWeek.SUNDAY
    }

    fun isIranStockTime(now: Long): Boolean {
        val t = Instant.ofEpochMilli(now).atZone(tehran)
        return t.dayOfWeek in setOf(DayOfWeek.SATURDAY, DayOfWeek.SUNDAY, DayOfWeek.MONDAY, DayOfWeek.TUESDAY, DayOfWeek.WEDNESDAY) &&
            !t.toLocalTime().isBefore(LocalTime.of(9, 0)) &&
            t.toLocalTime().isBefore(LocalTime.of(18, 0))
    }

    private fun isIranStockSessionOpen(item: MarketItem, now: Long): Boolean {
        val t = Instant.ofEpochMilli(now).atZone(tehran)
        val day = t.dayOfWeek
        if (day !in setOf(DayOfWeek.SATURDAY, DayOfWeek.SUNDAY, DayOfWeek.MONDAY, DayOfWeek.TUESDAY, DayOfWeek.WEDNESDAY)) return false
        val goldFund = item.category.contains("صندوق طلا") ||
            item.name.contains("صندوق طلا") ||
            item.code in setOf("عیار", "طلا", "کهربا", "گوهر", "زرفام", "مثقال")
        val start = if (goldFund) LocalTime.of(12, 0) else LocalTime.of(9, 0)
        val end = if (goldFund) LocalTime.of(18, 0) else LocalTime.of(12, 30)
        return !t.toLocalTime().isBefore(start) && t.toLocalTime().isBefore(end)
    }

    private fun isIranMarketSessionOpen(item: MarketItem, now: Long): Boolean {
        // Digital-asset pairs may update through the weekend.
        if (item.id == "usdt" || item.category.contains("ارز دیجیتال") || item.id.contains("crypto", true)) return true
        val t = Instant.ofEpochMilli(now).atZone(tehran)
        if (t.dayOfWeek == DayOfWeek.FRIDAY) return false
        val isFund = item.category.contains("صندوق")
        if (isFund && t.dayOfWeek == DayOfWeek.THURSDAY) return false
        val start = if (isFund) LocalTime.of(12, 0) else LocalTime.of(10, 0)
        val end = if (isFund) LocalTime.of(18, 0) else LocalTime.of(19, 0)
        return !t.toLocalTime().isBefore(start) && t.toLocalTime().isBefore(end)
    }
}

/** Never fabricate a trade timestamp from polling unless the observed quote changed. */
object QuoteTimestamp {
    fun choose(providerTime: Long, previousTime: Long, receivedAt: Long, changed: Boolean, sessionOpen: Boolean): Long = when {
        providerTime > 0L && providerTime <= receivedAt + 120_000L -> providerTime
        changed && sessionOpen -> receivedAt
        previousTime > 0L -> previousTime
        else -> 0L
    }
}
