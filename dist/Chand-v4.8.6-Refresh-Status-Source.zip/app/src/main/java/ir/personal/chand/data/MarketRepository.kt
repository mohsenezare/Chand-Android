package ir.personal.chand.data

import android.content.Context
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import okhttp3.Call
import okhttp3.Callback
import okhttp3.Response
import java.io.IOException
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.DateTimeParseException
import java.util.Locale
import java.util.UUID
import java.util.concurrent.TimeUnit

class MarketRepository(
    private val context: Context,
    private val httpClient: OkHttpClient = defaultHttpClient()
) {
    private val prefs = context.getSharedPreferences("chand_personal", Context.MODE_PRIVATE)
    private val legacyGlobalAliases = listOf(
        MarketDescriptor("gold_world", "OANDA:XAUUSD", "Gold Spot", "XAU/USD", "GOLD", MarketSource.TRADINGVIEW, "طلای جهانی", "دلار"),
        MarketDescriptor("silver", "OANDA:XAGUSD", "Silver Spot", "XAG/USD", "SILVER", MarketSource.TRADINGVIEW, "نقره جهانی", "دلار"),
        MarketDescriptor("brent", "TVC:UKOIL", "Brent Oil", "BRENT", "OIL", MarketSource.TRADINGVIEW, "انرژی جهانی", "دلار")
    )
    private val builtInDescriptors = DEFAULT_MARKET_DESCRIPTORS + TRADINGVIEW_MARKET_DESCRIPTORS + legacyGlobalAliases
    private val defaultById = builtInDescriptors.associateBy { it.id }
    private val defaultByKey = builtInDescriptors.associateBy { it.sourceKey }
    private val knownDescriptors = linkedMapOf<String, MarketDescriptor>()
    private val lastItems = linkedMapOf<String, MarketItem>()
    private val historyMutex = Mutex()
    private val historyCache = mutableMapOf<String, HistoryCacheEntry>()
    private val stockCatalogMutex = Mutex()
    private var stockCatalogLoadedAt = 0L
    private var stockCatalogCache: List<MarketDescriptor> = emptyList()
    private val resolvedTsetmcInsCodes = mutableMapOf<String, String>()
    private var lastCacheWriteAt = 0L
    private val retiredIds = linkedSetOf<String>()
    private val investingSymbolCache = mutableMapOf<String, String>()

    init {
        builtInDescriptors.forEach { knownDescriptors[it.id] = it }
        loadSelectedDescriptors().forEach { descriptor ->
            if (descriptor.id !in defaultById) knownDescriptors[descriptor.id] = descriptor
        }
        loadCached()?.items?.forEach { lastItems[it.id] = it.copy(origin = DataOrigin.CACHE) }
    }

    fun loadSettings(): UserSettings {
        val savedVisible = prefs.getString("visible_order_v3", null)
            ?: prefs.getString("visible_order_v2", null)
        val visible = savedVisible?.let { raw ->
            runCatching {
                val array = JSONArray(raw)
                buildList {
                    for (index in 0 until array.length()) {
                        array.optString(index).takeIf(String::isNotBlank)?.let(::add)
                    }
                }
            }.getOrNull()
        }?.let { if (it == LEGACY_DEFAULT_VISIBLE_IDS) DEFAULT_VISIBLE_IDS else it }
            ?: DEFAULT_VISIBLE_IDS

        return UserSettings(
            // Always start from the device light/dark setting, regardless of old saved preference.
            themeMode = ThemeMode.SYSTEM,
            gridMode = prefs.getBoolean("grid_mode", true),
            showBuyPrice = false,
            visibleIds = visible
        )
    }

    fun saveSettings(settings: UserSettings) {
        prefs.edit()
            .putString("theme_mode_v3", settings.themeMode.name)
            .putBoolean("grid_mode", settings.gridMode)
            .putBoolean("show_buy", false)
            .putString("visible_order_v3", JSONArray(settings.visibleIds).toString())
            .apply()
    }

    fun rememberSelection(ids: List<String>, descriptors: Collection<MarketDescriptor>): List<String> {
        synchronized(knownDescriptors) {
            descriptors.filterNot { it.id in retiredIds }.forEach {
                knownDescriptors[it.id] = defaultById[it.id] ?: it
            }
        }
        // The order chosen by the user is authoritative. Do not regroup defaults,
        // provider types, or alphabetically sort after a save.
        val ordered = ids.asSequence()
            .filterNot { it in retiredIds }
            .distinct()
            .filter { id ->
                synchronized(knownDescriptors) {
                    (defaultById[id] ?: knownDescriptors[id])?.let(::isAllowedDescriptor) == true
                }
            }
            .toList()
        saveSelectedDescriptors(ordered)
        return ordered
    }

    fun knownDescriptors(): List<MarketDescriptor> = synchronized(knownDescriptors) {
        knownDescriptors.values.toList()
    }

    fun startLiveStream(
        onState: (LiveConnectionState) -> Unit,
        onTicks: (List<StreamTick>) -> Unit
    ): MarketStreamClient {
        val streamHttpClient = httpClient.newBuilder()
            .callTimeout(0, TimeUnit.MILLISECONDS)
            .readTimeout(0, TimeUnit.MILLISECONDS)
            .pingInterval(15, TimeUnit.SECONDS)
            .build()
        return MarketStreamClient(streamHttpClient, onState, onTicks).also(MarketStreamClient::start)
    }

    fun startTradingViewLiveStream(
        symbols: List<String>,
        onState: (LiveConnectionState) -> Unit,
        onTicks: (List<StreamTick>) -> Unit
    ): TradingViewStreamClient {
        val streamHttpClient = httpClient.newBuilder()
            .callTimeout(6, TimeUnit.SECONDS)
            .connectTimeout(4, TimeUnit.SECONDS)
            .readTimeout(5, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .build()
        return TradingViewStreamClient(streamHttpClient, symbols, onState, onTicks)
            .also(TradingViewStreamClient::start)
    }

    fun startTsetmcLiveStream(
        insCodes: List<String>,
        onState: (LiveConnectionState) -> Unit,
        onTicks: (List<StreamTick>) -> Unit
    ): TsetmcLiveClient {
        val liveClient = httpClient.newBuilder()
            .callTimeout(5, TimeUnit.SECONDS)
            .connectTimeout(4, TimeUnit.SECONDS)
            .readTimeout(4, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .build()
        return TsetmcLiveClient(liveClient, insCodes, onState, onTicks).also(TsetmcLiveClient::start)
    }

    fun applyStreamTicks(visibleIds: List<String>, ticks: List<StreamTick>): MarketSnapshot? =
        applyLiveTicks(visibleIds, ticks, MarketSource.TGJU)

    fun applyTsetmcStreamTicks(visibleIds: List<String>, ticks: List<StreamTick>): MarketSnapshot? =
        applyLiveTicks(visibleIds, ticks, MarketSource.TSETMC)

    fun applyTradingViewStreamTicks(visibleIds: List<String>, ticks: List<StreamTick>): MarketSnapshot? =
        applyLiveTicks(visibleIds, ticks, MarketSource.TRADINGVIEW)

    private fun applyLiveTicks(
        visibleIds: List<String>,
        ticks: List<StreamTick>,
        source: MarketSource
    ): MarketSnapshot? {
        if (ticks.isEmpty() || visibleIds.isEmpty()) return null
        val visibleSet = visibleIds.toHashSet()
        val descriptorsByKey = synchronized(knownDescriptors) {
            knownDescriptors.values.asSequence()
                .filter { it.source == source && it.id in visibleSet }
                .groupBy(MarketDescriptor::sourceKey)
        }
        if (descriptorsByKey.isEmpty()) return null
        var changed = false
        synchronized(lastItems) {
            ticks.forEach { tick ->
                descriptorsByKey[tick.sourceKey].orEmpty().forEach descriptorLoop@{ descriptor ->
                    val previous = lastItems[descriptor.id]
                    if (previous != null && tick.sourceUpdatedAtMillis > 0L && previous.sourceUpdatedAtMillis > 0L && tick.sourceUpdatedAtMillis < previous.sourceUpdatedAtMillis) return@descriptorLoop
                    val scale = descriptor.valueScale
                    val price = tick.price * scale
                    if (!price.isFinite() || price <= 0.0) return@descriptorLoop
                    val now = System.currentTimeMillis()
                    val timestamp = QuoteTimestamp.choose(
                        tick.sourceUpdatedAtMillis,
                        previous?.sourceUpdatedAtMillis ?: 0L,
                        now,
                        changed = previous != null && previous.price != price,
                        sessionOpen = MarketSessionStatus.isSessionOpen(
                            MarketItem(descriptor.id, descriptor.name, descriptor.code, descriptor.symbol,
                                price, 0.0, 0.0, price, price, price, price, emptyList(), 0L, now,
                                DataOrigin.LIVE, true, source, descriptor.category, descriptor.unit),
                            now
                        )
                    )
                    val item = MarketItem(
                        id = descriptor.id, name = descriptor.name, code = descriptor.code, symbol = descriptor.symbol,
                        price = price, change = tick.change * scale, changePercent = tick.changePercent,
                        high = tick.high * scale, low = tick.low * scale,
                        buy = tick.bid?.times(scale)?.takeIf { it > 0.0 }
                            ?: previous?.buy?.takeIf { it > 0.0 } ?: price,
                        sell = tick.ask?.times(scale)?.takeIf { it > 0.0 }
                            ?: previous?.sell?.takeIf { it > 0.0 } ?: price,
                        history = MarketParsers.appendPoint(previous?.history.orEmpty(), timestamp, price),
                        sourceUpdatedAtMillis = timestamp, receivedAtMillis = System.currentTimeMillis(),
                        origin = DataOrigin.LIVE, isAvailable = true, source = source,
                        category = descriptor.category, unit = descriptor.unit
                    )
                    if (previous == null || previous.price != item.price || previous.sourceUpdatedAtMillis != item.sourceUpdatedAtMillis) {
                        lastItems[descriptor.id] = item
                        changed = true
                    }
                }
            }
        }
        if (!changed) return null
        return snapshotOf(visibleIds).also(::cacheSnapshotThrottled)
    }

    suspend fun fetch(
        visibleIds: List<String>,
        onPartialSnapshot: ((MarketSnapshot) -> Unit)? = null
    ): MarketSnapshot = withContext(Dispatchers.IO) {
        val descriptors = resolveVisibleDescriptors(visibleIds)
        if (descriptors.isEmpty()) return@withContext emptySnapshot()
        coroutineScope {
            val receivedAt = System.currentTimeMillis()
            val previous = synchronized(lastItems) { lastItems.toMap() }
            val requests = MarketSource.entries.map { source ->
                async {
                    val selected = descriptors.filter { it.source == source }
                    if (selected.isNotEmpty()) {
                        val result = requestResult {
                            when (source) {
                                MarketSource.TGJU -> fetchTgjuItems(selected, previous, receivedAt).items
                                MarketSource.TSETMC -> fetchTsetmcItems(selected, previous, receivedAt)
                                MarketSource.TRADINGVIEW -> fetchTradingViewItems(selected, previous, receivedAt)
                            }
                        }
                        currentCoroutineContext().ensureActive()
                        val fresh = result.getOrNull().orEmpty()
                        if (fresh.isNotEmpty()) {
                            synchronized(lastItems) {
                                fresh.forEach { incoming ->
                                    lastItems[incoming.id] = QuoteFreshness.prefer(lastItems[incoming.id], incoming)
                                }
                            }
                            // A slow provider must not hold back another provider's fresh prices.
                            onPartialSnapshot?.invoke(snapshotOf(visibleIds))
                        }
                    }
                }
            }
            requests.forEach { it.await() }
            snapshotOf(visibleIds).also(::cacheSnapshotThrottled)
        }
    }


    suspend fun fetchHistory(itemId: String, range: HistoryRange): HistorySeries =
        withContext(Dispatchers.IO) {
            var descriptor = synchronized(knownDescriptors) {
                knownDescriptors[itemId] ?: defaultById[itemId]
            } ?: return@withContext HistorySeries(range, emptyList(), "اطلاعات این مورد پیدا نشد")
            val inSession = synchronized(lastItems) { lastItems[itemId]?.history.orEmpty() }

            if (descriptor.source == MarketSource.TSETMC) {
                descriptor = resolveTsetmcDescriptor(descriptor) ?: descriptor
                val insCode = descriptor.sourceKey.takeIf { it.all(Char::isDigit) }
                if (insCode == null) {
                    return@withContext HistorySeries(range, MarketParsers.downsample(inSession, 360), "تاریخچه بورس در دسترس نیست")
                }
                return@withContext requestResult {
                    val top = when (range) {
                        HistoryRange.DAY -> 5
                        HistoryRange.WEEK -> 15
                        HistoryRange.MONTH -> 45
                        HistoryRange.YEAR -> 380
                        HistoryRange.FIVE_YEARS, HistoryRange.ALL -> 0
                    }
                    val rows = TsetmcProtocol.parseDailyList(
                        httpGet("$TSETMC_API/api/ClosingPrice/GetClosingPriceDailyList/$insCode/$top", 12_000)
                    )
                    val points = rows.asSequence()
                        .filter(TsetmcQuoteState::hasRealTrade)
                        .mapNotNull { q ->
                            TsetmcProtocol.toSourceTimestamp(q.dEven, q.hEven, fallbackToToday = false)
                                .takeIf { it > 0L }
                                ?.let { PricePoint(it, q.last) }
                        }
                        .sortedBy(PricePoint::timestampMillis)
                        .toList()
                    val merged = mergeHistory(points, inSession, range)
                    HistorySeries(range, if (range == HistoryRange.DAY) MarketParsers.downsample(merged, 360) else merged,
                        if (merged.isEmpty()) "تاریخچه‌ای از TSETMC دریافت نشد" else null)
                }.getOrElse {
                    HistorySeries(range, MarketParsers.downsample(inSession, 360),
                        if (inSession.isEmpty()) "دریافت نمودار بورس انجام نشد" else "نمایش تغییرات ثبت‌شده در این اجرا")
                }
            }

            if (descriptor.source == MarketSource.TRADINGVIEW) {
                return@withContext HistorySeries(
                    range,
                    MarketParsers.downsample(inSession, 360),
                    "برای Investing.com فعلاً تغییرات زنده همین اجرا نمایش داده می‌شود"
                )
            }

            requestResult {
                val cacheKind = if (range == HistoryRange.DAY) "day" else "long"
                val cacheKey = "${descriptor.sourceKey}:$cacheKind"
                val ttl = if (range == HistoryRange.DAY) 60_000L else 10 * 60_000L
                val now = System.currentTimeMillis()
                val cached = historyMutex.withLock {
                    historyCache[cacheKey]?.takeIf { now - it.loadedAtMillis < ttl }
                }
                val rawPoints = cached?.points ?: run {
                    val points = if (range == HistoryRange.DAY) {
                        val marketDate = synchronized(lastItems) {
                            lastItems[itemId]?.sourceUpdatedAtMillis?.takeIf { it > 0L }
                        }?.let { Instant.ofEpochMilli(it).atZone(TEHRAN_ZONE).toLocalDate() }
                            ?: java.time.LocalDate.now(TEHRAN_ZONE)
                        val body = httpGet(
                            "$TGJU_API/v1/market/indicator/today-table-data/${encode(descriptor.sourceKey)}?lang=fa",
                            20_000
                        )
                        MarketParsers.parseTodayHistory(body, marketDate, descriptor.valueScale)
                    } else {
                        val body = httpGet(
                            "$TGJU_API/v1/market/indicator/summary-table-data/${encode(descriptor.sourceKey)}?lang=fa&order_dir=asc",
                            25_000
                        )
                        MarketParsers.parseHistoricalHistory(body, descriptor.valueScale)
                    }
                    historyMutex.withLock { historyCache[cacheKey] = HistoryCacheEntry(now, points) }
                    points
                }
                val filtered = if (range == HistoryRange.DAY) rawPoints else {
                    MarketParsers.filterAndDownsampleHistory(rawPoints, range, now)
                }
                HistorySeries(range, mergeHistory(filtered, inSession, range),
                    if (filtered.isEmpty()) "تاریخچه‌ای از منبع دریافت نشد" else null)
            }.getOrElse {
                HistorySeries(range, MarketParsers.downsample(inSession, 360),
                    if (inSession.isEmpty()) "دریافت نمودار انجام نشد" else "نمایش تغییرات ثبت‌شده در این اجرا")
            }
        }

    suspend fun searchMarkets(query: String, page: Int): CatalogPage = withContext(Dispatchers.IO) {
        // TGJU is intentionally restricted to domestic non-stock markets. Global symbols
        // are supplied by TradingView so a selected global card has one authoritative source.
        val tgjuResult = requestResult { fetchTgjuCatalogModule("markets.internal", query, page) }
        val tgjuPage = tgjuResult.getOrNull()
        val tgjuDefaults = if (page == 1) DEFAULT_MARKET_DESCRIPTORS.filter { it.matches(query) } else emptyList()
        val tvDefaults = if (page == 1) TRADINGVIEW_MARKET_DESCRIPTORS.filter { it.matches(query) } else emptyList()
        val tvRemote = if (page == 1 && query.isNotBlank()) {
            requestResult { searchTradingViewCatalog(query) }.getOrDefault(emptyList())
        } else emptyList()
        val tgjuCandidates = (tgjuDefaults + tgjuPage?.items.orEmpty())
            .distinctBy(MarketDescriptor::id)
            .filterNot(::isTgjuStockDescriptor)
            .filterNot { descriptor ->
                descriptor.category.contains("جهانی") || descriptor.category.contains("global", ignoreCase = true)
            }
            .filterNot { it.id in retiredIds }
        val items = (tgjuCandidates + tvDefaults + tvRemote)
            .distinctBy(MarketDescriptor::id)
            .filterNot { it.id in retiredIds }
        synchronized(knownDescriptors) { items.forEach { knownDescriptors[it.id] = it } }
        CatalogPage(items, tgjuPage?.hasMore == true, null)
    }

    suspend fun searchStocks(query: String, page: Int): CatalogPage = withContext(Dispatchers.IO) {
        val normalized = query.trim()
        val catalog = requestResult { loadTsetmcCatalog(force = page == 1 && normalized.isBlank()) }
            .getOrDefault(stockCatalogCache)
        val localMatches = if (normalized.isBlank()) catalog else catalog.filter { it.matches(normalized) }
        val remoteMatches = if (normalized.isNotBlank() && page == 1) {
            requestResult { searchTsetmcRemote(normalized) }.getOrDefault(emptyList())
        } else emptyList()
        val combined = (localMatches + remoteMatches)
            .distinctBy(MarketDescriptor::id)
            .sortedWith(compareBy<MarketDescriptor> { it.code }.thenBy { it.name })
        val from = ((page - 1).coerceAtLeast(0)) * STOCK_PAGE_SIZE
        val to = (from + STOCK_PAGE_SIZE).coerceAtMost(combined.size)
        val items = if (from < combined.size) combined.subList(from, to) else emptyList()
        synchronized(knownDescriptors) { (combined + items).forEach { knownDescriptors[it.id] = it } }
        CatalogPage(items, to < combined.size, null)
    }

    suspend fun refreshIranMarketCatalogStrict(
        onProgress: (Int) -> Unit = {}
    ): List<MarketDescriptor> = withContext(Dispatchers.IO) {
        val all = linkedMapOf<String, MarketDescriptor>()
        var page = 1
        var finished = false

        while (!finished && page <= 60) {
            val result = fetchTgjuCatalogModule("markets.internal", "", page)
            result.items
                .filterNot(::isTgjuStockDescriptor)
                .filterNot { descriptor ->
                    descriptor.category.contains("جهانی") ||
                        descriptor.category.contains("global", ignoreCase = true)
                }
                .filterNot { it.id in retiredIds }
                .forEach { all[it.id] = it }

            onProgress(
                if (result.hasMore) (page * 12).coerceAtMost(92) else 100
            )
            finished = !result.hasMore
            page += 1
        }

        if (all.isEmpty()) {
            throw IllegalStateException("TGJU فهرست معتبری برای بازار ایران برنگرداند")
        }

        val items = all.values
            .distinctBy(MarketDescriptor::id)
            .sortedWith(compareBy<MarketDescriptor> { it.code }.thenBy { it.name })

        synchronized(knownDescriptors) {
            items.forEach { knownDescriptors[it.id] = it }
        }
        items
    }

    suspend fun refreshIranStockCatalogStrict(
        onProgress: (Int) -> Unit = {}
    ): List<MarketDescriptor> = withContext(Dispatchers.IO) {
        onProgress(12)
        var lastFailure: Throwable? = null

        val cdnQuotes = runCatching {
            TsetmcProtocol.parseCdnMarketWatch(httpGet(TSETMC_MARKET_WATCH, 15_000))
        }.onFailure { lastFailure = it }.getOrNull().orEmpty()

        onProgress(52)
        val quotes = if (cdnQuotes.isNotEmpty()) {
            cdnQuotes
        } else {
            runCatching {
                TsetmcProtocol.parseLegacyInit(httpGet(TSETMC_LEGACY_INIT, 15_000)).quotes
            }.onFailure { lastFailure = it }.getOrNull().orEmpty()
        }

        if (quotes.isEmpty()) {
            throw IllegalStateException(
                "TSETMC پاسخ معتبر برای فهرست بورس ایران نداد",
                lastFailure
            )
        }

        onProgress(82)
        val descriptors = quotes
            .mapNotNull(::descriptorFromTsetmcQuote)
            .distinctBy(MarketDescriptor::id)
            .sortedWith(compareBy<MarketDescriptor> { it.code }.thenBy { it.name })

        if (descriptors.isEmpty()) {
            throw IllegalStateException("فهرست بورس ایران خالی دریافت شد")
        }

        stockCatalogMutex.withLock {
            stockCatalogCache = descriptors
            stockCatalogLoadedAt = System.currentTimeMillis()
        }
        synchronized(knownDescriptors) {
            descriptors.forEach { knownDescriptors[it.id] = it }
        }
        onProgress(100)
        descriptors
    }

    suspend fun refreshGlobalInvestingCatalogStrict(
        onProgress: (Int) -> Unit = {}
    ): List<MarketDescriptor> = withContext(Dispatchers.IO) {
        val seeds = (
            ('A'..'Z').map { it.toString() } +
            ('0'..'9').map { it.toString() } +
            listOf(
                "USD", "EUR", "GBP", "JPY", "CHF",
                "BTC", "ETH", "XAU", "XAG",
                "OIL", "BRENT", "INDEX", "ETF"
            )
        ).distinct()

        val found = linkedMapOf<String, MarketDescriptor>()
        TRADINGVIEW_MARKET_DESCRIPTORS.forEach { found[it.id] = it }

        var successes = 0
        var lastFailure: Throwable? = null

        seeds.forEachIndexed { index, seed ->
            runCatching {
                searchTradingViewCatalog(seed)
            }.onSuccess { page ->
                successes += 1
                page
                    .filter { it.source == MarketSource.TRADINGVIEW }
                    .forEach { found[it.id] = it }
            }.onFailure {
                lastFailure = it
            }
            onProgress(
                (((index + 1) * 100.0) / seeds.size)
                    .toInt()
                    .coerceIn(0, 100)
            )
        }

        if (successes == 0) {
            throw IllegalStateException(
                "Investing پاسخ معتبر برای بازار جهانی نداد",
                lastFailure
            )
        }

        val items = found.values
            .distinctBy(MarketDescriptor::id)
            .sortedWith(compareBy<MarketDescriptor> { it.code }.thenBy { it.name })

        if (items.isEmpty()) {
            throw IllegalStateException("فهرست بازار جهانی خالی دریافت شد")
        }

        synchronized(knownDescriptors) {
            items.forEach { knownDescriptors[it.id] = it }
        }
        items
    }

    private suspend fun loadTsetmcCatalog(force: Boolean = false): List<MarketDescriptor> = stockCatalogMutex.withLock {
        val now = System.currentTimeMillis()
        if (!force && stockCatalogCache.isNotEmpty() && now - stockCatalogLoadedAt < STOCK_CATALOG_TTL_MS) {
            return@withLock stockCatalogCache
        }
        val quotes = requestResult {
            TsetmcProtocol.parseCdnMarketWatch(httpGet(TSETMC_MARKET_WATCH, 15_000))
        }.getOrNull()?.takeIf { it.isNotEmpty() } ?: requestResult {
            TsetmcProtocol.parseLegacyInit(httpGet(TSETMC_LEGACY_INIT, 15_000)).quotes
        }.getOrNull().orEmpty()
        if (quotes.isEmpty()) {
            if (stockCatalogCache.isNotEmpty()) return@withLock stockCatalogCache
            error("TSETMC market catalog unavailable")
        }
        val descriptors = quotes.mapNotNull(::descriptorFromTsetmcQuote)
            .distinctBy(MarketDescriptor::id)
            .sortedWith(compareBy<MarketDescriptor> { it.code }.thenBy { it.name })
        require(descriptors.isNotEmpty()) { "TSETMC returned no instruments" }
        stockCatalogCache = descriptors
        stockCatalogLoadedAt = now
        synchronized(knownDescriptors) { descriptors.forEach { knownDescriptors[it.id] = it } }
        descriptors
    }

    private suspend fun searchTsetmcRemote(query: String): List<MarketDescriptor> {
        val root = JSONObject(httpGet("$TSETMC_API/api/Instrument/GetInstrumentSearch/${encode(query)}", 12_000))
        val raw = firstPresent(root, "instrumentSearch", "instrument", "data", "response")
        return objectList(raw).mapNotNull { row ->
            val insCode = firstString(listOf(row), "insCode", "instrumentCode", "instrumentID")?.trim().orEmpty()
            if (!insCode.all(Char::isDigit) || insCode.isBlank()) return@mapNotNull null
            val ticker = firstString(listOf(row), "lVal18AFC", "lVal18", "symbol", "instrumentName")?.trim().orEmpty()
            if (ticker.isBlank()) return@mapNotNull null
            val company = firstString(listOf(row), "lVal30", "lVal30AFC", "companyName", "companyNamePersian")?.trim().orEmpty()
            val flow = firstNumber(listOf(row), "flow")?.toInt() ?: 0
            stockDescriptorFromFields(insCode, ticker, company, flow)
        }.distinctBy(MarketDescriptor::id)
    }

    private fun descriptorFromTsetmcQuote(q: TsetmcQuoteState): MarketDescriptor? {
        if (q.insCode.isBlank() || q.symbol.isBlank()) return null
        return stockDescriptorFromFields(q.insCode, q.symbol, q.name, q.flow)
    }

    private fun stockDescriptorFromFields(insCode: String, ticker: String, company: String, flow: Int): MarketDescriptor {
        val category = when (flow) {
            1 -> "بورس ایران · بورس تهران"
            2 -> "بورس ایران · فرابورس"
            4 -> "بورس ایران · پایه"
            else -> "بورس ایران"
        }
        return MarketDescriptor(
            id = "tsetmc:$insCode",
            sourceKey = insCode,
            name = company.ifBlank { ticker },
            code = ticker,
            symbol = "TSE",
            source = MarketSource.TSETMC,
            category = category,
            unit = "ریال",
            valueScale = 1.0
        )
    }

    private suspend fun fetchTgjuItems(
        descriptors: List<MarketDescriptor>,
        previousItems: Map<String, MarketItem>,
        receivedAtMillis: Long
    ): MarketParsers.IndicatorResult {
        val allItems = mutableListOf<MarketItem>()
        val missing = linkedSetOf<String>()
        descriptors.distinctBy(MarketDescriptor::sourceKey).chunked(40).forEach { chunk ->
            val keys = chunk.joinToString(",") { encode(it.sourceKey) }
            val parsed = MarketParsers.parseTgjuIndicators(
                httpGet("$TGJU_API/v1/widget/tmp?keys=$keys", 8_000),
                chunk,
                previousItems,
                receivedAtMillis
            )
            allItems += parsed.items
            missing += parsed.missingSourceKeys
        }
        if (allItems.isEmpty()) error("TGJU returned no valid prices")
        return MarketParsers.IndicatorResult(allItems, missing)
    }

    private suspend fun fetchTgjuStockItems(
        descriptors: List<MarketDescriptor>,
        previousItems: Map<String, MarketItem>,
        receivedAtMillis: Long
    ): List<MarketItem> {
        val html = httpGet(TGJU_STOCK_PAGE, 12_000)
        val items = descriptors.mapNotNull { descriptor ->
            val ticker = descriptor.code.ifBlank { descriptor.sourceKey }.trim()
            val rowPattern = Regex(
                "(?is)<tr[^>]*data-symbol=[\\\"']${Regex.escape(ticker)}[\\\"'][^>]*>(.*?)</tr>"
            )
            val row = rowPattern.find(html)?.groupValues?.getOrNull(1) ?: return@mapNotNull null
            val cells = Regex("(?is)<td[^>]*>(.*?)</td>")
                .findAll(row)
                .map { cleanHtmlCell(it.groupValues[1]) }
                .toList()
            if (cells.size < 8) return@mapNotNull null

            val previous = previousItems[descriptor.id]
            // TGJU stock table: last trade, closing price, then yesterday. During
            // closed/no-trade periods we deliberately fall back to the last known
            // valid value instead of showing zero or "unavailable".
            val lastTrade = parseHtmlNumber(cells.getOrNull(4).orEmpty())?.takeIf { it > 0.0 }
            val closing = parseHtmlNumber(cells.getOrNull(7).orEmpty())?.takeIf { it > 0.0 }
            val yesterday = parseHtmlNumber(cells.getOrNull(15).orEmpty())?.takeIf { it > 0.0 }
            // If there is no new trade right now, keep the last *traded* price we already
            // observed before falling back to closing/yesterday values. This prevents a
            // halted or quiet symbol from jumping to a non-trade reference price.
            val price = lastTrade ?: previous?.price?.takeIf { it > 0.0 } ?: closing ?: yesterday
                ?: return@mapNotNull null

            val change = when {
                lastTrade != null -> parseHtmlNumber(cells.getOrNull(5).orEmpty()) ?: previous?.change ?: 0.0
                closing != null -> parseHtmlNumber(cells.getOrNull(8).orEmpty()) ?: previous?.change ?: 0.0
                else -> previous?.change ?: 0.0
            }
            val percent = when {
                lastTrade != null -> parseHtmlNumber(cells.getOrNull(6).orEmpty()) ?: previous?.changePercent ?: 0.0
                closing != null -> parseHtmlNumber(cells.getOrNull(9).orEmpty()) ?: previous?.changePercent ?: 0.0
                else -> previous?.changePercent ?: 0.0
            }
            val changed = previous == null || previous.price != price
            val sourceTimestamp = if (changed) receivedAtMillis else {
                previous?.sourceUpdatedAtMillis?.takeIf { it > 0L } ?: receivedAtMillis
            }
            MarketItem(
                id = descriptor.id, name = descriptor.name, code = descriptor.code, symbol = descriptor.symbol,
                price = price, change = change, changePercent = percent,
                high = previous?.high?.takeIf { it > 0.0 } ?: price,
                low = previous?.low?.takeIf { it > 0.0 } ?: price,
                buy = previous?.buy?.takeIf { it > 0.0 } ?: price,
                sell = previous?.sell?.takeIf { it > 0.0 } ?: price,
                history = if (changed) {
                    MarketParsers.appendPoint(previous?.history.orEmpty(), receivedAtMillis, price)
                } else previous?.history.orEmpty(),
                sourceUpdatedAtMillis = sourceTimestamp,
                receivedAtMillis = receivedAtMillis,
                origin = DataOrigin.NETWORK, isAvailable = true, source = MarketSource.TGJU,
                category = descriptor.category, unit = descriptor.unit
            )
        }
        if (items.isEmpty()) error("TGJU stock page returned no selected quotes")
        return items
    }

    private fun cleanHtmlCell(raw: String): String = raw
        .replace(Regex("(?is)<!--.*?-->"), " ")
        .replace(Regex("(?is)<[^>]+>"), " ")
        .replace("&nbsp;", " ")
        .replace("&amp;", "&")
        .replace("&quot;", "\"")
        .replace("&#39;", "'")
        .replace(Regex("\\s+"), " ")
        .trim()

    private fun parseHtmlNumber(raw: String): Double? {
        val normalized = buildString(raw.length) {
            raw.forEach { ch ->
                append(
                    when (ch) {
                        '۰', '٠' -> '0'; '۱', '١' -> '1'; '۲', '٢' -> '2'; '۳', '٣' -> '3';
                        '۴', '٤' -> '4'; '۵', '٥' -> '5'; '۶', '٦' -> '6'; '۷', '٧' -> '7';
                        '۸', '٨' -> '8'; '۹', '٩' -> '9'; '−', '–', '—' -> '-'; else -> ch
                    }
                )
            }
        }.replace(",", "")
        return Regex("[-+]?\\d+(?:\\.\\d+)?").find(normalized)?.value?.toDoubleOrNull()
    }

    private fun isTgjuStockDescriptor(descriptor: MarketDescriptor): Boolean =
        descriptor.source == MarketSource.TGJU &&
            (descriptor.category.contains("بورس ایران") || descriptor.category.contains("سهام"))

    private suspend fun fetchTsetmcItems(
        descriptors: List<MarketDescriptor>,
        previousItems: Map<String, MarketItem>,
        receivedAtMillis: Long
    ): List<MarketItem> = coroutineScope {
        descriptors.map { descriptor ->
            async {
                requestResult {
                    val resolved = resolveTsetmcDescriptor(descriptor) ?: error("TSETMC instrument not resolved")
                    val insCode = resolved.sourceKey
                    val current = requestResult {
                        TsetmcProtocol.parseClosingPriceInfo(
                            httpGet("$TSETMC_API/api/ClosingPrice/GetClosingPriceInfo/$insCode", 8_000)
                        )
                    }.getOrNull()
                    val previous = previousItems[descriptor.id] ?: previousItems[resolved.id]
                    val quote = when {
                        current?.hasRealTrade == true -> current
                        previous?.price?.takeIf { it > 0.0 } != null -> null
                        else -> requestResult {
                            TsetmcProtocol.parseDailyList(
                                httpGet("$TSETMC_API/api/ClosingPrice/GetClosingPriceDailyList/$insCode/15", 10_000)
                            ).firstOrNull { it.hasRealTrade }
                        }.getOrNull()
                    }

                    if (quote == null && previous != null && previous.price > 0.0) {
                        return@requestResult previous.copy(
                            id = descriptor.id,
                            name = resolved.name,
                            code = resolved.code,
                            symbol = resolved.symbol,
                            receivedAtMillis = receivedAtMillis,
                            origin = DataOrigin.CACHE,
                            isAvailable = true,
                            source = MarketSource.TSETMC,
                            category = resolved.category,
                            unit = resolved.unit
                        )
                    }
                    val q = quote ?: error("No real TSETMC last trade")
                    val price = q.last.takeIf { it > 0.0 } ?: error("Invalid TSETMC last trade")
                    val timestamp = QuoteTimestamp.choose(
                        providerTime = TsetmcProtocol.toSourceTimestamp(q.dEven, q.hEven),
                        previousTime = previous?.sourceUpdatedAtMillis ?: 0L,
                        receivedAt = receivedAtMillis,
                        changed = previous != null && previous.price != price,
                        sessionOpen = MarketSessionStatus.isSessionOpen(
                            MarketItem(descriptor.id, resolved.name, resolved.code, resolved.symbol,
                                price, 0.0, 0.0, price, price, price, price, emptyList(), 0L,
                                receivedAtMillis, DataOrigin.NETWORK, true,
                                MarketSource.TSETMC, resolved.category, resolved.unit),
                            receivedAtMillis
                        )
                    )
                    val yesterday = q.yesterday.takeIf { it > 0.0 }
                    val change = yesterday?.let { price - it } ?: previous?.change ?: 0.0
                    val percent = yesterday?.let { if (it != 0.0) change / it * 100.0 else 0.0 }
                        ?: previous?.changePercent ?: 0.0
                    val high = q.high.takeIf { it > 0.0 } ?: previous?.high?.takeIf { it > 0.0 } ?: price
                    val low = q.low.takeIf { it > 0.0 } ?: previous?.low?.takeIf { it > 0.0 } ?: price
                    val changed = previous == null || previous.price != price || previous.sourceUpdatedAtMillis != timestamp
                    MarketItem(
                        id = descriptor.id,
                        name = resolved.name,
                        code = resolved.code,
                        symbol = resolved.symbol,
                        price = price,
                        change = change,
                        changePercent = percent,
                        high = high,
                        low = low,
                        buy = q.bid?.takeIf { it > 0.0 } ?: previous?.buy?.takeIf { it > 0.0 } ?: price,
                        sell = q.ask?.takeIf { it > 0.0 } ?: previous?.sell?.takeIf { it > 0.0 } ?: price,
                        history = if (changed) MarketParsers.appendPoint(previous?.history.orEmpty(), timestamp, price)
                            else previous?.history.orEmpty(),
                        sourceUpdatedAtMillis = timestamp,
                        receivedAtMillis = receivedAtMillis,
                        origin = DataOrigin.NETWORK,
                        isAvailable = true,
                        source = MarketSource.TSETMC,
                        category = resolved.category,
                        unit = resolved.unit
                    )
                }.getOrNull()
            }
        }.mapNotNull { it.await() }
    }

    private suspend fun resolveTsetmcDescriptor(input: MarketDescriptor): MarketDescriptor? {
        if (input.source == MarketSource.TSETMC && input.sourceKey.all(Char::isDigit)) return input
        resolvedTsetmcInsCodes[input.id]?.let { ins ->
            synchronized(knownDescriptors) { knownDescriptors[input.id] }?.takeIf { it.sourceKey == ins }?.let { return it }
        }
        val query = input.code.takeIf { it.isNotBlank() && it != "—" } ?: input.sourceKey.ifBlank { input.name }
        val candidates = searchTsetmcRemote(query)
        val exact = candidates.firstOrNull { it.code.equals(input.code, ignoreCase = true) }
            ?: candidates.firstOrNull { it.code.equals(input.sourceKey, ignoreCase = true) }
            ?: candidates.firstOrNull { it.name == input.name }
            ?: candidates.firstOrNull()
            ?: return null
        val migrated = exact.copy(id = input.id)
        resolvedTsetmcInsCodes[input.id] = exact.sourceKey
        synchronized(knownDescriptors) { knownDescriptors[input.id] = migrated }
        return migrated
    }

    private suspend fun searchTradingViewCatalog(query: String): List<MarketDescriptor> {
        if (query.isBlank()) return emptyList()
        val url = investingEndpoint("search") +
            "?query=" + encode(query) + "&limit=$TRADINGVIEW_SEARCH_LIMIT&type=&exchange="
        val rows = JSONArray(httpGetTradingView(url, 10_000))
        return buildList {
            for (i in 0 until rows.length()) {
                val row = rows.optJSONObject(i) ?: continue
                val rawSymbol = row.optString("symbol").trim()
                val fullName = row.optString("full_name").trim()
                val exchange = row.optString("exchange").trim()
                val sourceKey = when {
                    fullName.isNotBlank() -> fullName
                    exchange.isNotBlank() && rawSymbol.isNotBlank() -> "$exchange:$rawSymbol"
                    else -> continue
                }
                if (exchange.equals("TSE", true) || exchange.contains("TEHRAN", true)) continue

                synchronized(investingSymbolCache) { investingSymbolCache[sourceKey] = sourceKey }

                val description = row.optString("description").trim().ifBlank { rawSymbol }
                val type = row.optString("type").trim().lowercase(Locale.ROOT)
                val currency = row.optString("currency").trim()
                    .ifBlank { row.optString("currency_code").trim() }
                    .uppercase(Locale.US)
                val category = when {
                    type.contains("crypto") -> "ارز دیجیتال جهانی"
                    type.contains("fx") || type.contains("currency") -> "فارکس جهانی"
                    type.contains("future") -> "آتی جهانی"
                    type.contains("commodity") -> "کالا جهانی"
                    type.contains("index") -> "شاخص جهانی"
                    type.contains("stock") || type.contains("fund") || type.contains("etf") -> "سهام جهانی"
                    else -> "بازار جهانی"
                }
                val symbol = when {
                    type.contains("crypto") -> "CRYPTO"
                    type.contains("fx") || type.contains("currency") -> "FX"
                    type.contains("index") -> "INDEX"
                    type.contains("stock") || type.contains("fund") || type.contains("etf") -> "STOCK"
                    else -> "MARKET"
                }
                val unit = when (currency) {
                    "USD" -> "دلار"; "EUR" -> "یورو"; "GBP" -> "پوند"
                    "JPY" -> "ین"; "CHF" -> "فرانک"; "" -> ""; else -> currency
                }
                add(
                    MarketDescriptor(
                        "tv:$sourceKey",
                        sourceKey,
                        description,
                        rawSymbol.ifBlank { sourceKey.substringAfterLast(':') },
                        symbol,
                        MarketSource.TRADINGVIEW,
                        category,
                        unit,
                        1.0
                    )
                )
            }
        }.distinctBy(MarketDescriptor::id).take(TRADINGVIEW_SEARCH_LIMIT)
    }

    private suspend fun fetchTradingViewItems(
        descriptors: List<MarketDescriptor>,
        previousItems: Map<String, MarketItem>,
        receivedAtMillis: Long
    ): List<MarketItem> {
        if (descriptors.isEmpty()) return emptyList()

        val resolvedPairs = coroutineScope {
            descriptors.distinctBy(MarketDescriptor::sourceKey).map { descriptor ->
                async { descriptor.sourceKey to resolveInvestingSymbol(descriptor) }
            }.map { it.await() }
        }
        val resolved = resolvedPairs.mapNotNull { (sourceKey, investingName) ->
            investingName?.let { sourceKey to it }
        }.toMap()
        if (resolved.isEmpty()) return emptyList()

        val url = investingEndpoint("quotes") +
            "?symbols=" + encode(resolved.values.distinct().joinToString(","))
        val root = JSONObject(httpGetTradingView(url, 8_000))
        val rows = root.optJSONArray("d") ?: JSONArray()
        val rowByName = linkedMapOf<String, JSONObject>()
        for (index in 0 until rows.length()) {
            val row = rows.optJSONObject(index) ?: continue
            val name = row.optString("n").trim()
            if (name.isNotBlank()) rowByName[name] = row
        }

        return descriptors.mapNotNull { descriptor ->
            val investingName = resolved[descriptor.sourceKey] ?: return@mapNotNull null
            val row = rowByName[investingName]
                ?: rowByName.entries.firstOrNull { it.key.equals(investingName, true) }?.value
                ?: return@mapNotNull null
            val status = row.optString("s")
            if (status.isNotBlank() && !status.equals("ok", true)) return@mapNotNull null
            val values = row.optJSONObject("v") ?: return@mapNotNull null
            val price = investingNumber(values.opt("lp"))
                ?: investingNumber(values.opt("last"))
                ?: investingNumber(values.opt("close"))
                ?: return@mapNotNull null
            if (!price.isFinite() || price <= 0.0) return@mapNotNull null

            val previous = previousItems[descriptor.id]
            val percent = investingNumber(values.opt("chp"))
                ?: investingNumber(values.opt("rchp"))
                ?: 0.0
            val change = investingNumber(values.opt("ch"))
                ?: investingNumber(values.opt("rch"))
                ?: if (percent != 0.0) price * percent / 100.0 else 0.0
            val high = investingNumber(values.opt("high_price"))
                ?: investingNumber(values.opt("high"))
                ?: previous?.high?.takeIf { it > 0.0 } ?: price
            val low = investingNumber(values.opt("low_price"))
                ?: investingNumber(values.opt("low"))
                ?: previous?.low?.takeIf { it > 0.0 } ?: price
            val buy = investingNumber(values.opt("bid"))?.takeIf { it > 0.0 }
                ?: previous?.buy?.takeIf { it > 0.0 } ?: price
            val sell = investingNumber(values.opt("ask"))?.takeIf { it > 0.0 }
                ?: previous?.sell?.takeIf { it > 0.0 } ?: price
            val sourceTime = QuoteTimestamp.choose(
                providerTime = investingSourceTimestamp(values) ?: 0L,
                previousTime = previous?.sourceUpdatedAtMillis ?: 0L,
                receivedAt = receivedAtMillis,
                changed = previous != null && previous.price != price,
                sessionOpen = MarketSessionStatus.isGlobalSessionOpen(
                    descriptor.sourceKey + " " + descriptor.code, descriptor.category, receivedAtMillis
                )
            )

            MarketItem(
                id = descriptor.id,
                name = descriptor.name,
                code = descriptor.code,
                symbol = descriptor.symbol,
                price = price,
                change = change,
                changePercent = percent,
                high = high,
                low = low,
                buy = buy,
                sell = sell,
                history = if (previous?.price == price) previous?.history.orEmpty()
                    else MarketParsers.appendPoint(previous?.history.orEmpty(), sourceTime, price),
                sourceUpdatedAtMillis = sourceTime,
                receivedAtMillis = receivedAtMillis,
                origin = DataOrigin.NETWORK,
                isAvailable = true,
                source = MarketSource.TRADINGVIEW,
                category = descriptor.category,
                unit = descriptor.unit
            )
        }
    }

    private suspend fun resolveInvestingSymbol(descriptor: MarketDescriptor): String? {
        synchronized(investingSymbolCache) {
            investingSymbolCache[descriptor.sourceKey]?.let { return it }
        }

        directInvestingNameForSourceKey(descriptor.sourceKey)?.let { direct ->
            synchronized(investingSymbolCache) { investingSymbolCache[descriptor.sourceKey] = direct }
            return direct
        }

        val query = investingQueryFor(descriptor.sourceKey)
        val url = investingEndpoint("search") +
            "?query=" + encode(query) + "&limit=12&type=&exchange="
        val rows = runCatching { JSONArray(httpGetTradingView(url, 8_000)) }.getOrNull()
        val preferredExchange = descriptor.sourceKey.substringBefore(':', "").uppercase(Locale.US)
        val expected = normalizeInvestingToken(descriptor.sourceKey.substringAfterLast(':'))

        val best = if (rows != null) {
            (0 until rows.length()).mapNotNull(rows::optJSONObject)
                .maxByOrNull { row ->
                    val symbol = row.optString("symbol").trim()
                    val fullName = row.optString("full_name").trim()
                    val description = row.optString("description").trim()
                    val exchange = row.optString("exchange").trim().uppercase(Locale.US)
                    val type = row.optString("type").trim().lowercase(Locale.US)
                    val symbolToken = normalizeInvestingToken(symbol)
                    val fullToken = normalizeInvestingToken(fullName.substringAfterLast(':'))
                    val queryToken = normalizeInvestingToken(query)
                    var score = 0
                    if (symbolToken == expected) score += 160
                    if (fullToken == expected) score += 150
                    if (symbolToken == queryToken) score += 130
                    if (fullToken == queryToken) score += 120
                    if (description.contains(query, true)) score += 70
                    if (preferredExchange.isNotBlank() && exchange == preferredExchange) score += 35
                    if (expected in setOf("XAUUSD", "XAGUSD", "EURUSD", "GBPUSD", "USDJPY") &&
                        (type.contains("fx") || type.contains("currency"))) score += 40
                    if (expected in setOf("BTCUSD", "ETHUSD") && type.contains("crypto")) score += 40
                    if (expected == "UKOIL" && description.contains("brent", true)) score += 80
                    if (expected == "USOIL" &&
                        (description.contains("wti", true) || description.contains("crude oil", true))) score += 80
                    score
                }
        } else null

        val fullName = best?.optString("full_name")?.trim().orEmpty()
        val exchange = best?.optString("exchange")?.trim().orEmpty()
        val symbol = best?.optString("symbol")?.trim().orEmpty()
        val resolved = when {
            fullName.isNotBlank() -> fullName
            exchange.isNotBlank() && symbol.isNotBlank() -> "$exchange:$symbol"
            descriptor.sourceKey.isNotBlank() -> descriptor.sourceKey
            else -> return null
        }
        synchronized(investingSymbolCache) { investingSymbolCache[descriptor.sourceKey] = resolved }
        return resolved
    }

    private fun directInvestingNameForSourceKey(sourceKey: String): String? {
        val token = normalizeInvestingToken(sourceKey.substringAfterLast(':'))
        val direct = when (token) {
            "BTCUSD" -> ":BTC/USD"
            "ETHUSD" -> ":ETH/USD"
            "EURUSD" -> ":EUR/USD"
            "GBPUSD" -> ":GBP/USD"
            "USDJPY" -> ":USD/JPY"
            "XAUUSD" -> ":XAU/USD"
            "XAGUSD" -> ":XAG/USD"
            else -> null
        }
        if (direct != null) return direct

        val prefix = sourceKey.substringBefore(':', "").uppercase(Locale.US)
        return if (sourceKey.startsWith(":") ||
            (sourceKey.contains(':') && prefix !in setOf("BITSTAMP", "FX", "FX_IDC", "OANDA", "FOREXCOM", "TVC"))
        ) sourceKey else null
    }

    private fun investingQueryFor(sourceKey: String): String =
        when (normalizeInvestingToken(sourceKey.substringAfterLast(':'))) {
            "BTCUSD" -> "BTC/USD"
            "ETHUSD" -> "ETH/USD"
            "EURUSD" -> "EUR/USD"
            "GBPUSD" -> "GBP/USD"
            "USDJPY" -> "USD/JPY"
            "XAUUSD" -> "XAU/USD"
            "XAGUSD" -> "XAG/USD"
            "UKOIL" -> "Brent Oil"
            "USOIL" -> "Crude Oil WTI"
            else -> sourceKey.substringAfterLast(':')
        }

    private fun normalizeInvestingToken(value: String): String =
        value.uppercase(Locale.US).filter(Char::isLetterOrDigit)

    private fun investingEndpoint(name: String): String =
        "$INVESTING_TVC_BASE/${UUID.randomUUID().toString().replace("-", "")}/0/0/0/0/$name"

    private fun investingSourceTimestamp(value: JSONObject): Long? {
        val raw = sequenceOf(
            value.opt("lp_time"), value.opt("trade_time"), value.opt("rtc"), value.opt("timestamp")
        ).mapNotNull(::investingNumber).firstOrNull { it > 0.0 } ?: return null
        val millis = if (raw < 10_000_000_000L) (raw * 1000.0).toLong() else raw.toLong()
        return millis.takeIf { it in 946684800000L..4102444800000L }
    }

    private fun investingNumber(raw: Any?): Double? = when (raw) {
        null, JSONObject.NULL -> null
        is Number -> raw.toDouble()
        else -> raw.toString().replace(",", "").trim().toDoubleOrNull()
    }


    private suspend fun fetchTgjuCatalogModule(module: String, query: String, page: Int): CatalogModulePage {
        val queryPart = query.trim().takeIf { it.isNotEmpty() }?.let { "&q=${encode(it)}" }.orEmpty()
        val root = JSONObject(httpGet("$TGJU_API/v1/newsearch?module=$module&page=$page$queryPart", 8_000))
        val items = objectList(root.opt("list"))
            .filter(::isActiveTgjuRecord)
            .mapNotNull(::parseTgjuDescriptor)
        return CatalogModulePage(items, !root.optBoolean("last", false) && items.isNotEmpty())
    }

    private fun isActiveTgjuRecord(value: JSONObject): Boolean {
        val type = value.optString("type").lowercase(Locale.ROOT)
        val category = value.optString("category").lowercase(Locale.ROOT)
        val title = value.optString("title").lowercase(Locale.ROOT)
        val status = value.optString("status").lowercase(Locale.ROOT)
        val tradeStatus = value.optString("trade_status").lowercase(Locale.ROOT)

        // TGJU keeps historical/closed instruments in dedicated collections.
        // Exclude those when they leak into generic search results, but do not
        // drop an instrument merely because the market is currently closed.
        if (type.contains("closedasset") || type.contains("archive") || type.contains("historical")) return false
        if (category.contains("قدیمی") || category.contains("حذف") || category.contains("منقضی")) return false
        if (title.contains("قدیمی") || title.contains("حذف شده") || title.contains("منقضی")) return false
        if (status in setOf("deleted", "expired", "inactive", "archived")) return false
        if (tradeStatus in setOf("deleted", "expired", "inactive", "archived")) return false

        fun explicitFalse(key: String): Boolean = value.has(key) && when (val raw = value.opt(key)) {
            is Boolean -> !raw
            is Number -> raw.toInt() == 0
            else -> raw.toString().trim().lowercase(Locale.ROOT) in setOf("0", "false", "no", "inactive")
        }
        if (explicitFalse("is_active") || explicitFalse("active") || explicitFalse("isActive")) return false
        if (isExpiredByDate(value)) return false
        return true
    }

    private fun isExpiredByDate(value: JSONObject): Boolean {
        val expiryKeys = listOf(
            "expires_at", "expired_at", "expiration_date", "expiry_date",
            "end_at", "end_date", "active_to", "date_to", "maturity_date"
        )
        val today = LocalDate.now(TEHRAN_ZONE)
        expiryKeys.forEach { key ->
            val raw = value.optString(key).trim()
            if (raw.isBlank()) return@forEach
            parseCatalogDate(raw)?.let { date ->
                if (date.isBefore(today)) return true
            }
        }
        return false
    }

    private fun parseCatalogDate(raw: String): LocalDate? {
        val normalized = raw.take(10).replace('/', '-')
        // Do not interpret a Jalali year as a Gregorian expiration.
        if ((normalized.substringBefore('-').toIntOrNull() ?: 0) < 1900) return null
        return try {
            LocalDate.parse(normalized, DateTimeFormatter.ISO_LOCAL_DATE)
        } catch (_: DateTimeParseException) {
            null
        }
    }

    private fun parseTgjuDescriptor(value: JSONObject): MarketDescriptor? {
        val type = value.optString("type").trim()
        if (!type.startsWith("markets.")) return null
        val title = value.optString("title").trim()
        if (title.isBlank()) return null
        val rawUnit = value.optString("s2").trim().lowercase(Locale.ROOT)
        val isStockCollection = type.contains("internal.stocks", ignoreCase = true)
        val allowedStockKinds = setOf("stock", "equity", "share", "etf", "fund")
        if (isStockCollection && rawUnit.isNotBlank() && rawUnit !in allowedStockKinds) return null
        val stockLike = isStockCollection || rawUnit in allowedStockKinds
        val sourceKey = sequenceOf(
            value.optString("s3"), value.optString("grade"), value.optString("s1"),
            value.optString("symbol"), value.optString("code")
        ).map(String::trim).firstOrNull(String::isNotBlank) ?: return null
        defaultByKey[sourceKey]?.let { return it }
        val rawCategory = value.optString("category").trim()
        val category = when {
            stockLike && rawCategory.isNotBlank() -> "بورس ایران · $rawCategory"
            stockLike -> "بورس ایران"
            rawCategory.isNotBlank() -> rawCategory
            type.contains("global") -> "بازار جهانی"
            else -> "بازار داخلی"
        }
        val english = value.optString("title_en").trim()
        val grade = value.optString("grade").trim()
        val s1 = value.optString("s1").trim()
        val code = when {
            stockLike && grade.isNotBlank() -> grade.take(22)
            stockLike && s1.isNotBlank() -> s1.take(22)
            grade.length in 2..18 && grade.matches(Regex("[A-Za-z0-9_./-]+")) -> grade.uppercase(Locale.US)
            english.length in 2..22 -> english
            else -> sourceKey.uppercase(Locale.US).take(18)
        }
        val (unit, scale) = when {
            stockLike -> "ریال" to 1.0
            rawUnit == "irr" -> "تومان" to 0.1
            rawUnit == "usd" -> "دلار" to 1.0
            rawUnit == "eur" -> "یورو" to 1.0
            rawUnit.isBlank() -> "" to 1.0
            else -> rawUnit.uppercase(Locale.US) to 1.0
        }
        return MarketDescriptor(
            id = "tgju:$sourceKey", sourceKey = sourceKey, name = title, code = code,
            symbol = symbolFor(type, category, title), source = MarketSource.TGJU,
            category = category, unit = unit, valueScale = scale
        )
    }

    private fun snapshotOf(visibleIds: List<String>, message: String? = null): MarketSnapshot {
        val descriptors = resolveVisibleDescriptors(visibleIds)
        val items = synchronized(lastItems) {
            descriptors.map { descriptor ->
                lastItems[descriptor.id]?.copy(symbol = descriptor.symbol) ?: unavailableItem(descriptor)
            }
        }
        val available = items.filter(MarketItem::isAvailable)
        val latest = available.maxOfOrNull(MarketItem::sourceUpdatedAtMillis) ?: 0L
        return MarketSnapshot(
            updatedAt = if (latest > 0L) Instant.ofEpochMilli(latest).toString() else "",
            items = items,
            isDemo = available.isEmpty(),
            message = message
        )
    }

    private fun emptySnapshot() = MarketSnapshot("", emptyList(), false)

    private fun resolveVisibleDescriptors(ids: List<String>): List<MarketDescriptor> =
        synchronized(knownDescriptors) {
            ids.distinct()
                .filterNot { it in retiredIds }
                .mapNotNull { defaultById[it] ?: knownDescriptors[it] }
                .filter(::isAllowedDescriptor)
        }

    /** Returns only ids that are still active and come from the two allowed providers. */
    fun sanitizeVisibleIds(ids: List<String>): List<String> = synchronized(knownDescriptors) {
        ids.distinct().filter { id ->
            id !in retiredIds && (defaultById[id] ?: knownDescriptors[id])?.let(::isAllowedDescriptor) == true
        }
    }

    private fun isAllowedDescriptor(descriptor: MarketDescriptor): Boolean =
        descriptor.source == MarketSource.TGJU ||
            descriptor.source == MarketSource.TSETMC ||
            descriptor.source == MarketSource.TRADINGVIEW

    private fun unavailableItem(descriptor: MarketDescriptor) = MarketItem(
        id = descriptor.id,
        name = descriptor.name,
        code = descriptor.code,
        symbol = descriptor.symbol,
        price = 0.0,
        change = 0.0,
        changePercent = 0.0,
        high = 0.0,
        low = 0.0,
        buy = 0.0,
        sell = 0.0,
        history = emptyList(),
        sourceUpdatedAtMillis = 0L,
        receivedAtMillis = 0L,
        origin = DataOrigin.UNAVAILABLE,
        isAvailable = false,
        source = descriptor.source,
        category = descriptor.category,
        unit = descriptor.unit
    )

    private fun mergeHistory(
        source: List<PricePoint>,
        live: List<PricePoint>,
        range: HistoryRange
    ): List<PricePoint> {
        if (live.isEmpty()) return source
        val merged = (source + live)
            .associateBy(PricePoint::timestampMillis)
            .values
            .sortedBy(PricePoint::timestampMillis)
        return if (range == HistoryRange.DAY) MarketParsers.downsample(merged, 360) else merged
    }

    private suspend fun httpGet(url: String, timeoutMillis: Long): String {
        val request = Request.Builder()
            .url(url)
            .header("Accept", "application/json,text/plain,*/*")
            .header("Cache-Control", "no-cache")
            .header("User-Agent", HTTP_USER_AGENT)
            .build()
        val call = httpClient.newCall(request)
        call.timeout().timeout(timeoutMillis, TimeUnit.MILLISECONDS)
        return executeCancellable(call)
    }

    private suspend fun httpGetTradingView(url: String, timeoutMillis: Long): String {
        val request = Request.Builder()
            .url(url)
            .header("Accept", "application/json,text/plain,*/*")
            .header("Cache-Control", "no-cache")
            .header("Pragma", "no-cache")
            .header("Referer", "https://tvc-invdn-com.investing.com/")
            .header("User-Agent", HTTP_USER_AGENT)
            .build()
        val call = httpClient.newCall(request)
        call.timeout().timeout(timeoutMillis, TimeUnit.MILLISECONDS)
        return executeCancellable(call)
    }

    private suspend fun httpPost(url: String, jsonBody: String, timeoutMillis: Long): String {
        val body = jsonBody.toRequestBody("text/plain; charset=utf-8".toMediaType())
        val request = Request.Builder()
            .url(url)
            .post(body)
            .header("Accept", "application/json,text/plain,*/*")
            .header("Origin", "https://www.tradingview.com")
            .header("Referer", "https://www.tradingview.com/")
            .header("Cache-Control", "no-cache")
            .header("User-Agent", HTTP_USER_AGENT)
            .build()
        val call = httpClient.newCall(request)
        call.timeout().timeout(timeoutMillis, TimeUnit.MILLISECONDS)
        return executeCancellable(call)
    }

    private suspend fun executeCancellable(call: Call): String = suspendCancellableCoroutine { continuation ->
        continuation.invokeOnCancellation { call.cancel() }
        call.enqueue(object : Callback {
            override fun onFailure(call: Call, error: IOException) {
                continuation.resumeWithException(error)
            }
            override fun onResponse(call: Call, response: Response) {
                val result = runCatching {
                    response.use {
                        check(it.isSuccessful) { "HTTP ${it.code}" }
                        it.body?.string()?.takeIf(String::isNotBlank) ?: error("Empty response")
                    }
                }
                result.fold({ continuation.resume(it) }, { continuation.resumeWithException(it) })
            }
        })
    }

    private suspend fun <T> requestResult(block: suspend () -> T): Result<T> = try {
        Result.success(block())
    } catch (cancelled: CancellationException) {
        throw cancelled
    } catch (error: Exception) {
        Result.failure(error)
    }

    fun flushCache() {
        val items = synchronized(lastItems) { lastItems.values.filter(MarketItem::isAvailable) }
        if (items.isNotEmpty()) prefs.edit().putString(
            "cached_snapshot_v3", snapshotToJson(MarketSnapshot("", items, false)).toString()
        ).apply()
    }

    private fun jsonNumber(value: Any?): Double? = when (value) {
        null, JSONObject.NULL -> null
        is Number -> value.toDouble()
        else -> value.toString().replace(",", "").trim().toDoubleOrNull()
    }

    private fun cacheSnapshotThrottled(snapshot: MarketSnapshot) {
        val validItems = snapshot.items.filter(MarketItem::isAvailable)
        if (validItems.isEmpty()) return
        val now = System.currentTimeMillis()
        if (now - lastCacheWriteAt < 30_000L) return
        lastCacheWriteAt = now
        flushCache()
    }

    private fun loadCached(): MarketSnapshot? = prefs.getString("cached_snapshot_v3", null)
        ?.let { runCatching { parseCachedSnapshot(it) }.getOrNull() }

    private fun parseCachedSnapshot(body: String): MarketSnapshot {
        val root = JSONObject(body)
        val items = objectList(root.opt("items")).mapNotNull { value ->
            val id = value.optString("id")
            val descriptor = defaultById[id] ?: synchronized(knownDescriptors) { knownDescriptors[id] }
            val price = number(value, "price") ?: return@mapNotNull null
            if (price <= 0.0) return@mapNotNull null
            val history = objectList(value.opt("history")).mapNotNull { point ->
                val timestamp = point.optLong("timestamp", 0L)
                val historyValue = number(point, "value")
                if (timestamp > 0L && historyValue != null) PricePoint(timestamp, historyValue) else null
            }.ifEmpty {
                listOf(PricePoint(value.optLong("sourceUpdatedAtMillis", 0L), price))
                    .filter { it.timestampMillis > 0L }
            }
            MarketItem(
                id = id,
                name = value.optString("name", descriptor?.name.orEmpty()),
                code = value.optString("code", descriptor?.code.orEmpty()),
                symbol = descriptor?.symbol ?: value.optString("symbol", "•"),
                price = price,
                change = number(value, "change") ?: 0.0,
                changePercent = number(value, "changePercent") ?: 0.0,
                high = number(value, "high") ?: price,
                low = number(value, "low") ?: price,
                buy = number(value, "buy") ?: price,
                sell = number(value, "sell") ?: price,
                history = history,
                sourceUpdatedAtMillis = value.optLong("sourceUpdatedAtMillis", 0L),
                receivedAtMillis = value.optLong("receivedAtMillis", 0L),
                origin = DataOrigin.CACHE,
                isAvailable = true,
                source = runCatching { MarketSource.valueOf(value.optString("source")) }
                    .getOrDefault(descriptor?.source ?: MarketSource.TGJU),
                category = value.optString("category", descriptor?.category.orEmpty()),
                unit = value.optString("unit", descriptor?.unit ?: "تومان")
            )
        }
        require(items.isNotEmpty()) { "Price cache is empty" }
        return MarketSnapshot(root.optString("updatedAt"), items, false)
    }

    private fun snapshotToJson(snapshot: MarketSnapshot): JSONObject = JSONObject().apply {
        put("updatedAt", snapshot.updatedAt)
        put("items", JSONArray().apply {
            snapshot.items.forEach { item ->
                put(JSONObject().apply {
                    put("id", item.id)
                    put("name", item.name)
                    put("code", item.code)
                    put("symbol", item.symbol)
                    put("price", item.price)
                    put("change", item.change)
                    put("changePercent", item.changePercent)
                    put("high", item.high)
                    put("low", item.low)
                    put("buy", item.buy)
                    put("sell", item.sell)
                    put("sourceUpdatedAtMillis", item.sourceUpdatedAtMillis)
                    put("receivedAtMillis", item.receivedAtMillis)
                    put("source", item.source.name)
                    put("category", item.category)
                    put("unit", item.unit)
                    put("history", JSONArray().apply {
                        item.history.forEach { point ->
                            put(JSONObject().put("timestamp", point.timestampMillis).put("value", point.value))
                        }
                    })
                })
            }
        })
    }

    private fun saveSelectedDescriptors(ids: List<String>) {
        val selected = synchronized(knownDescriptors) {
            ids.mapNotNull(knownDescriptors::get).filter { it.id !in defaultById }
        }
        prefs.edit().putString(
            "selected_descriptors_v4",
            JSONArray().apply {
                selected.forEach { descriptor ->
                    put(JSONObject().apply {
                        put("id", descriptor.id)
                        put("sourceKey", descriptor.sourceKey)
                        put("name", descriptor.name)
                        put("code", descriptor.code)
                        put("symbol", descriptor.symbol)
                        put("source", descriptor.source.name)
                        put("category", descriptor.category)
                        put("unit", descriptor.unit)
                        put("valueScale", descriptor.valueScale)
                    })
                }
            }.toString()
        ).apply()
    }

    private fun loadSelectedDescriptors(): List<MarketDescriptor> {
        val raw = prefs.getString("selected_descriptors_v4", null)
            ?: prefs.getString("selected_descriptors_v3", null)
            ?: prefs.getString("selected_descriptors_v2", null)
            ?: return emptyList()
        return runCatching {
            objectList(JSONArray(raw)).mapNotNull { value ->
                val id = value.optString("id")
                val sourceKey = value.optString("sourceKey")
                val name = value.optString("name")
                if (id.isBlank() || sourceKey.isBlank() || name.isBlank()) return@mapNotNull null
                val oldUnit = value.optString("unit")
                val category = value.optString("category")
                val rawSource = value.optString("source")
                var source = runCatching { MarketSource.valueOf(rawSource) }.getOrDefault(MarketSource.TGJU)
                var migratedSourceKey = sourceKey
                var migratedUnit = oldUnit
                var scale = value.optDouble("valueScale", 1.0)

                // v3 used TGJU for Tehran stocks. Keep the user's id/order but migrate
                // those descriptors to TSETMC; the InsCode is resolved on first refresh.
                if (source == MarketSource.TGJU && (category.contains("بورس ایران") || category.contains("سهام"))) {
                    source = MarketSource.TSETMC
                    migratedSourceKey = value.optString("code").takeIf { it.isNotBlank() && it != "—" } ?: sourceKey
                    migratedUnit = "ریال"
                    scale = 1.0
                } else if (source == MarketSource.TGJU && oldUnit == "ریال" && !category.contains("بورس")) {
                    migratedUnit = "تومان"
                    scale = 0.1
                }
                MarketDescriptor(
                    id = id,
                    sourceKey = migratedSourceKey,
                    name = name,
                    code = value.optString("code", "—"),
                    symbol = value.optString("symbol", if (source == MarketSource.TSETMC) "TSE" else "•"),
                    source = source,
                    category = if (source == MarketSource.TSETMC && category.isBlank()) "بورس ایران" else category,
                    unit = migratedUnit,
                    valueScale = scale
                )
            }
        }.getOrDefault(emptyList())
    }

    private fun MarketDescriptor.matches(raw: String): Boolean {
        val query = raw.trim().lowercase(Locale.ROOT)
        return query.isEmpty() || name.lowercase(Locale.ROOT).contains(query) ||
            code.lowercase(Locale.ROOT).contains(query) ||
            category.lowercase(Locale.ROOT).contains(query)
    }

    private fun symbolFor(type: String, category: String, title: String): String {
        val value = "$type $category $title"
        return when {
            title.contains("یورو") -> "EUR"
            title.contains("دلار آمریکا") -> "USD"
            title.contains("پوند") -> "GBP"
            title.contains("ین ژاپن") -> "JPY"
            title.contains("یوان") -> "CNY"
            title.contains("درهم") -> "AED"
            title.contains("لیر") -> "TRY"
            title.contains("روبل") -> "RUB"
            title.contains("روپیه") -> "INR"
            title.contains("بیت کوین") || title.contains("بیت‌کوین") -> "BTC"
            title.contains("اتریوم") -> "ETH"
            title.contains("تتر") -> "USDT"
            value.contains("ارز دیجیتال") || type.contains("crypto") -> "CRYPTO"
            value.contains("طلا") || value.contains("سکه") -> "GOLD"
            value.contains("نقره") -> "SILVER"
            value.contains("نفت") || value.contains("انرژی") -> "OIL"
            value.contains("ارز") -> "FX"
            value.contains("بورس") || value.contains("سهام") || value.contains("صندوق") -> "TSE"
            value.contains("خودرو") -> "CAR"
            else -> "MARKET"
        }
    }

    private fun number(value: JSONObject, key: String): Double? {
        val raw = value.opt(key) ?: return null
        return when (raw) {
            is Number -> raw.toDouble()
            is JSONObject -> number(raw, "value")
            else -> raw.toString().replace(",", "").trim().toDoubleOrNull()
        }
    }

    private fun firstString(objects: List<JSONObject>, vararg keys: String): String? {
        objects.forEach { value ->
            keys.forEach { key -> value.optString(key).takeIf(String::isNotBlank)?.let { return it } }
        }
        return null
    }

    private fun firstNumber(objects: List<JSONObject>, vararg keys: String): Double? {
        objects.forEach { value -> keys.forEach { key -> number(value, key)?.let { return it } } }
        return null
    }

    private fun objectList(value: Any?): List<JSONObject> = when (value) {
        is JSONArray -> buildList {
            for (index in 0 until value.length()) value.optJSONObject(index)?.let(::add)
        }
        is JSONObject -> {
            val isRecord = listOf("id", "name", "title", "instrument", "closingPrice", "sourceKey", "price")
                .any(value::has)
            if (isRecord) listOf(value) else buildList {
                val keys = value.keys()
                while (keys.hasNext()) value.optJSONObject(keys.next())?.let(::add)
            }
        }
        else -> emptyList()
    }

    private fun firstPresent(value: JSONObject, vararg keys: String): Any? {
        keys.forEach { key -> value.opt(key)?.takeUnless { it == JSONObject.NULL }?.let { return it } }
        return null
    }

    private fun encode(value: String): String = URLEncoder.encode(value, StandardCharsets.UTF_8.name())

    private data class CatalogModulePage(val items: List<MarketDescriptor>, val hasMore: Boolean)
    private data class HistoryCacheEntry(val loadedAtMillis: Long, val points: List<PricePoint>)

    companion object {
        private const val TGJU_API = "https://api.tgju.org"
        private const val TGJU_STOCK_PAGE = "https://www.tgju.org/markets/stock"
        private const val STOCK_CATALOG_TTL_MS = 2 * 60_000L
        private const val STOCK_PAGE_SIZE = 100
        private const val TSETMC_API = "https://cdn.tsetmc.com"
        private const val TSETMC_LEGACY_INIT = "https://old.tsetmc.com/tsev2/data/MarketWatchInit.aspx?h=0&r=0"
        private const val TSETMC_MARKET_WATCH =
            "https://cdn.tsetmc.com/api/ClosingPrice/GetMarketWatch?market=0&industrialGroup=&" +
                "paperTypes%5B0%5D=1&paperTypes%5B1%5D=2&paperTypes%5B2%5D=3&" +
                "paperTypes%5B3%5D=4&paperTypes%5B4%5D=5&paperTypes%5B5%5D=6&" +
                "paperTypes%5B6%5D=7&paperTypes%5B7%5D=8&paperTypes%5B8%5D=9&" +
                "showTraded=false&withBestLimits=true&hEven=0&RefID=0"
        private const val INVESTING_TVC_BASE = "https://tvc6.investing.com"
        private const val TRADINGVIEW_SCANNER_BASE = "https://scanner.tradingview.com"
        private const val TRADINGVIEW_SEARCH = "https://symbol-search.tradingview.com/symbol_search/"
        private const val TRADINGVIEW_SEARCH_LIMIT = 80
        private val TEHRAN_ZONE = ZoneId.of("Asia/Tehran")
        private const val HTTP_USER_AGENT =
            "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126 Mobile Safari/537.36 Chand/4.0"

        fun defaultHttpClient(): OkHttpClient = OkHttpClient.Builder()
            .connectTimeout(8, TimeUnit.SECONDS)
            .readTimeout(10, TimeUnit.SECONDS)
            .writeTimeout(10, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .build()
    }
}
