package ir.personal.chand.data

internal object QuoteFreshness {
    fun prefer(current: MarketItem?, incoming: MarketItem): MarketItem {
        if (current == null || !current.isAvailable) return incoming
        if (!incoming.isAvailable) return current
        val oldTime = current.sourceUpdatedAtMillis
        val newTime = incoming.sourceUpdatedAtMillis
        if (oldTime > 0L && newTime <= 0L) return current
        if (oldTime > 0L && newTime > 0L && newTime != oldTime) {
            return if (newTime > oldTime) incoming else current
        }
        return if (incoming.receivedAtMillis >= current.receivedAtMillis) incoming else current
    }

    fun merge(current: MarketSnapshot?, incoming: MarketSnapshot): MarketSnapshot {
        val byId = current?.items.orEmpty().associateBy(MarketItem::id)
        return incoming.copy(items = incoming.items.map { prefer(byId[it.id], it) })
    }
}
