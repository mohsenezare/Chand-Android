package ir.personal.chand.ui

import org.junit.Assert.*
import org.junit.Test

class PullRefreshGestureTest {
    @Test fun repeatsWithoutFling() {
        val gesture = PullRefreshGesture(72f)
        repeat(10) {
            gesture.reset() // pointer down / up, with no fling callback
            assertFalse(gesture.drag(30f, true, false))
            assertTrue(gesture.drag(42f, true, false))
            assertFalse(gesture.drag(100f, true, false))
        }
    }
    @Test fun ignoresRefreshingAndScrolledContent() {
        val gesture = PullRefreshGesture(72f)
        assertFalse(gesture.drag(100f, false, false))
        assertFalse(gesture.drag(100f, true, true))
        gesture.reset()
        assertTrue(gesture.drag(72f, true, false))
    }
    @Test fun reverseAndCancelledGesturesDoNotAccumulate() {
        val gesture = PullRefreshGesture(72f)
        assertFalse(gesture.drag(50f, true, false))
        assertFalse(gesture.drag(-1f, true, false))
        assertFalse(gesture.drag(50f, true, false))
        gesture.reset()
        assertFalse(gesture.drag(50f, true, false))
        assertTrue(gesture.drag(22f, true, false))
        assertFalse(gesture.drag(-1f, true, false))
        assertFalse(gesture.drag(100f, true, false))
    }
}
