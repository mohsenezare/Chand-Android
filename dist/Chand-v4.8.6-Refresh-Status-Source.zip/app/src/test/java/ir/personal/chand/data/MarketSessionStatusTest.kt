package ir.personal.chand.data

import org.junit.Assert.*
import org.junit.Test
import java.time.LocalDateTime
import java.time.ZoneId

class MarketSessionStatusTest {
    private fun at(zone: String, y: Int = 2026, m: Int = 10, d: Int, h: Int, min: Int = 0): Long =
        LocalDateTime.of(y, m, d, h, min).atZone(ZoneId.of(zone)).toInstant().toEpochMilli()

    private fun item(source: MarketSource, id: String, code: String, category: String, now: Long,
                     updated: Long = now): MarketItem = MarketItem(
        id, id, code, code, 100.0, 0.0, 0.0, 100.0, 100.0, 100.0, 100.0,
        emptyList(), updated, now, DataOrigin.NETWORK, true, source, category
    )

    @Test fun saturdayClosesGoldFxAndOilButNotCrypto() {
        val now = at("America/New_York", d = 24, h = 12) // Saturday
        assertFalse(MarketSessionStatus.isLive(item(MarketSource.TRADINGVIEW, "gold_world", "XAU/USD", "طلای جهانی", now), now))
        assertFalse(MarketSessionStatus.isLive(item(MarketSource.TRADINGVIEW, "fx:EURUSD", "EUR/USD", "فارکس جهانی", now), now))
        assertFalse(MarketSessionStatus.isLive(item(MarketSource.TRADINGVIEW, "brent", "BRENT", "انرژی جهانی", now), now))
        assertTrue(MarketSessionStatus.isLive(item(MarketSource.TRADINGVIEW, "tv:BTCUSD", "BTC/USD", "ارز دیجیتال جهانی", now), now))
    }
    @Test fun forexOpensOnSundayWhileSpotGoldWaitsUntil6pmNewYork() {
        val now = at("America/New_York", d = 25, h = 17, min = 30)
        assertTrue(MarketSessionStatus.isLive(item(MarketSource.TRADINGVIEW, "eurusd", "EUR/USD", "فارکس جهانی", now), now))
        assertFalse(MarketSessionStatus.isLive(item(MarketSource.TRADINGVIEW, "gold", "XAU/USD", "طلای جهانی", now), now))
    }
    @Test fun tehranMarketClosedFridayAndAfterHoursAndUsdtAlwaysOpen() {
        val friday = at("Asia/Tehran", d = 23, h = 12)
        val saturdayMorning = at("Asia/Tehran", d = 24, h = 11)
        val saturdayNight = at("Asia/Tehran", d = 24, h = 23)
        assertFalse(MarketSessionStatus.isLive(item(MarketSource.TGJU, "gold18", "GRAM", "طلای ۱۸ عیار", friday), friday))
        assertTrue(MarketSessionStatus.isLive(item(MarketSource.TGJU, "gold18", "GRAM", "طلای ۱۸ عیار", saturdayMorning), saturdayMorning))
        assertFalse(MarketSessionStatus.isLive(item(MarketSource.TGJU, "gold18", "GRAM", "طلای ۱۸ عیار", saturdayNight), saturdayNight))
        assertTrue(MarketSessionStatus.isLive(item(MarketSource.TGJU, "usdt", "USDT", "ارز دیجیتال داخلی", friday), friday))
    }
    @Test fun tehranStocksFollowSaturdayWednesdaySession() {
        val mondayNoon = at("Asia/Tehran", d = 26, h = 11)
        val mondayAfter = at("Asia/Tehran", d = 26, h = 14)
        val thursday = at("Asia/Tehran", d = 29, h = 11)
        assertTrue(MarketSessionStatus.isLive(item(MarketSource.TSETMC, "tsetmc:123", "فولاد", "بورس ایران", mondayNoon), mondayNoon))
        assertFalse(MarketSessionStatus.isLive(item(MarketSource.TSETMC, "tsetmc:123", "فولاد", "بورس ایران", mondayAfter), mondayAfter))
        assertFalse(MarketSessionStatus.isLive(item(MarketSource.TSETMC, "tsetmc:123", "فولاد", "بورس ایران", thursday), thursday))
    }
    @Test fun receiptTimeDoesNotFalselyFreshenRepeatedQuote() {
        val last = at("America/New_York", d = 23, h = 12)
        val saturday = at("America/New_York", d = 24, h = 12)
        assertEquals(last, QuoteTimestamp.choose(0, last, saturday, false, false))
        assertEquals(0L, QuoteTimestamp.choose(0, 0, saturday, false, true))
        assertEquals(last, QuoteTimestamp.choose(0, last, saturday, true, false))
        assertEquals(saturday, QuoteTimestamp.choose(0, last, saturday, true, true))
    }
    @Test fun invalidFutureQuoteIsNotLive() {
        val now = at("Asia/Tehran", d = 24, h = 12)
        assertFalse(MarketSessionStatus.isLive(item(MarketSource.TGJU, "usd", "USD", "ارز آزاد", now, now + 500_000L), now))
    }
    @Test fun staleCryptoAndCachedQuotesAreNotClosedOrLive() {
        val now = at("America/New_York", d = 24, h = 12)
        val crypto = item(MarketSource.TRADINGVIEW, "tv:BTCUSD", "BTC/USD", "ارز دیجیتال جهانی", now)
        assertEquals(MarketSessionStatus.Status.LIVE, MarketSessionStatus.status(crypto, now))
        assertEquals(MarketSessionStatus.Status.STALE, MarketSessionStatus.status(crypto.copy(sourceUpdatedAtMillis = now - 600_000L), now))
        assertEquals(MarketSessionStatus.Status.STALE, MarketSessionStatus.status(crypto.copy(origin = DataOrigin.CACHE), now))
        assertEquals(MarketSessionStatus.Status.STALE, MarketSessionStatus.status(crypto.copy(isAvailable = false), now))
        val fx = item(MarketSource.TRADINGVIEW, "fx:EURUSD", "EUR/USD", "فارکس جهانی", now)
        assertEquals(MarketSessionStatus.Status.CLOSED, MarketSessionStatus.status(fx, now))
    }
}
