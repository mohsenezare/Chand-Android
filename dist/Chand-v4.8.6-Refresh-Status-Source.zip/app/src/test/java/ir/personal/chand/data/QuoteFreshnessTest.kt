package ir.personal.chand.data

import org.junit.Assert.*
import org.junit.Test

class QuoteFreshnessTest {
    private fun quote(time: Long, received: Long, price: Double = 100.0) = MarketItem(
        "usd", "Dollar", "USD", "USD", price, 0.0, 0.0, price, price, price, price,
        emptyList(), time, received, DataOrigin.NETWORK, true
    )

    @Test fun olderHttpCannotOverwriteLiveTick() {
        val live = quote(200, 200).copy(origin = DataOrigin.LIVE)
        assertSame(live, QuoteFreshness.prefer(live, quote(100, 300)))
    }
    @Test fun newerHttpIsNotBlockedByRecentLiveOrigin() {
        val live = quote(200, 200).copy(origin = DataOrigin.LIVE)
        val fresh = quote(300, 201, 110.0)
        assertSame(fresh, QuoteFreshness.prefer(live, fresh))
    }
    @Test fun sameTimestampUsesReceiptOrder() {
        val fresh = quote(200, 300)
        assertSame(fresh, QuoteFreshness.prefer(fresh, quote(200, 250)))
        assertSame(fresh, QuoteFreshness.prefer(quote(200, 250), fresh))
    }
    @Test fun unavailableAndMissingTimestampCannotReplaceValidPrice() {
        val valid = quote(200, 300)
        assertSame(valid, QuoteFreshness.prefer(valid, quote(0, 400)))
        assertSame(valid, QuoteFreshness.prefer(valid, quote(300, 400).copy(isAvailable = false)))
    }
    @Test fun concurrentSnapshotPreservesNewerPricesAndIncomingOrder() {
        val fresh = quote(200, 300)
        val other = quote(100, 100).copy(id = "euro")
        val current = MarketSnapshot("", listOf(fresh), false)
        val incoming = MarketSnapshot("", listOf(other, quote(100, 200)), false)
        val merged = QuoteFreshness.merge(current, incoming)
        assertEquals(listOf("euro", "usd"), merged.items.map { it.id })
        assertSame(fresh, merged.items.last())
    }
}
